/*
 * Voice changer untuk Sambung (cowok -> cewek).
 *
 * Dipakai sebagai AudioWorklet (lihat bagian bawah) dan juga bisa di-require di Node untuk tes.
 *
 * Cara kerja singkat:
 *  1. Pelacak nada (NSDF/McLeod) jalan tiap 128 sampel pada sinyal yang sudah di-lowpass dan di-decimate.
 *  2. Pelacak "pitch mark": menandai puncak tiap siklus suara, disejajarkan dengan korelasi bentuk gelombang.
 *  3. Sintesis PSOLA: potongan (grain) 2 periode di-Hann lalu ditumpuk dengan jarak baru.
 *       - Jarak antar-grain  -> mengatur NADA (pitch).
 *       - Resampling grain   -> mengatur FORMANT (warna suara), terpisah dari pitch.
 *     Jadi suara cowok bisa naik ke nada cewek tanpa jadi chipmunk.
 *  4. Nada keluaran dikunci ke target tiap preset (bukan "naik X semitone"), memakai rata-rata nada
 *     pembicara yang dipelajari otomatis. Hasilnya konsisten untuk suara cowok berat maupun tipis.
 *  5. Bagian tak bersuara (s, sh, napas, jeda) dilewatkan apa adanya lewat grain identitas, jadi tidak ada
 *     artefak "robot" di konsonan. Kalau pelacak ragu, selalu jatuh ke jalur aman itu.
 *
 * Latensi efek: default 45 ms, bisa dipilih di UI (minimum sekitar 35 ms). Preset Normal: 0 ms.
 */
(function (root) {
  'use strict';

  const HOP = 128;                 // jarak antar frame analisis (sampel)
  const RING = 1 << 15, RM = RING - 1;
  const FRING = 512, FM = FRING - 1;
  const MRING = 4096, MM = MRING - 1;
  const LN = Math.log;
  const V_ENTER = 0.45, V_STAY = 0.25, V_SURE = 0.5, V_HANG = 10;   // ambang keputusan bersuara (lihat _analyze)

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  class VoiceEngine {
    constructor(sr) {
      this.sr = sr;
      this.D = Math.max(1, Math.round(sr / 8000));          // decimasi untuk pelacak nada (~8 kHz)
      this.srd = sr / this.D;
      this.tauMin = Math.max(4, Math.floor(this.srd / 500)); // nada tertinggi yang dilacak: 500 Hz
      this.tauMax = Math.ceil(this.srd / 70) + 2;            // nada terendah: 70 Hz
      this.W = 192;
      this.seg = new Float32Array(this.W + this.tauMax + 4);
      this.nsdf = new Float32Array(this.tauMax + 4);
      this.Tmax = sr / 70;
      this.Lq = Math.round(0.045 * sr);                      // latensi efek (bisa diatur lewat configure({delay: ms}))
      this.HW = Math.ceil(this.Tmax) + 4;                    // setengah panjang grain terbesar
      this.dc = Math.round(this.W * this.D / 2 + 0.004 * sr);// selisih waktu pusat frame analisis terhadap "sekarang"
      this.Hu = Math.round(0.004 * sr);                      // setengah panjang grain identitas
      this.LqMin = this.dc + this.HW + 64;                   // delay minimum supaya analisis tidak telat (underrun)

      // ring buffer
      this.xr = new Float32Array(RING);   // sinyal mentah
      this.xl = new Float32Array(RING);   // sinyal lowpass 1 kHz (untuk nada & pitch mark)
      this.xd = new Float32Array(RING);   // hasil decimate
      this.ob = new Float32Array(RING);   // akumulator keluaran
      this.n = 0;                         // jumlah sampel masuk
      this.nd = 0;                        // jumlah sampel decimated
      this.accD = 0; this.cntD = 0;

      // filter: highpass 1-kutub (60 Hz) + lowpass biquad Butterworth 1 kHz
      {
        const wh = 2 * Math.PI * 80 / sr, ch = Math.cos(wh), ah = Math.sin(wh) / (2 * Math.SQRT1_2), a0h = 1 + ah;
        this.hb0 = ((1 + ch) / 2) / a0h; this.hb1 = -(1 + ch) / a0h; this.hb2 = this.hb0;
        this.ha1 = (-2 * ch) / a0h; this.ha2 = (1 - ah) / a0h;
      }
      this.hx1 = 0; this.hx2 = 0; this.hy1 = 0; this.hy2 = 0;
      const w0 = 2 * Math.PI * 1000 / sr, cs = Math.cos(w0), al = Math.sin(w0) / (2 * Math.SQRT1_2);
      const a0 = 1 + al;
      this.lb0 = ((1 - cs) / 2) / a0; this.lb1 = (1 - cs) / a0; this.lb2 = this.lb0;
      this.la1 = (-2 * cs) / a0; this.la2 = (1 - al) / a0;
      this.lx1 = 0; this.lx2 = 0; this.ly1 = 0; this.ly2 = 0;

      // frame nada
      this.fTag = new Int32Array(FRING).fill(-1);
      this.fV = new Uint8Array(FRING);
      this.fT = new Float32Array(FRING);
      this.fRun = new Int32Array(FRING);
      this.kLast = -1;
      this.vs = false; this.vc = 0; this.uc = 0;
      this.lnT = LN(sr / 120); this.Tprev = 0; this.hist = [0, 0, 0]; this.hn = 0;
      this.mu = LN(125); this.muN = 0;     // rata-rata log-F0 pembicara
      this.run = 0;
      this.lastClarity = 0;

      // pitch mark
      this.mPos = new Float64Array(MRING);
      this.mPer = new Float32Array(MRING);
      this.mRun = new Int32Array(MRING);
      this.mcount = 0; this.mptr = 0;
      this.trk = { active: false, last: 0, pol: 1 };
      this.ref = new Float32Array(2048);

      // sintesis
      this.ts = 0;           // posisi grain berikutnya (waktu keluaran)
      this.emitted = 0;      // indeks keluaran pertama yang belum dikirim
      this.mix = 0; this.mixTarget = 0; this.mixStep = 1 / (0.03 * sr);
      this.idle = true;
      this.P = { f0: 225, formant: 1.17, inton: 1, tune: 0 };
      this.stat = { f0in: 0, f0out: 0, voiced: 0, underrun: 0, heal: 0 };
      this.muteN = 0;                   // sisa sampel bisu setelah refresh (cegah suara asli lolos saat analisis mulai ulang)
      this.autoHeal = true;             // saklar refresh otomatis (UI)
      this.leakN = 0; this.deadN = 0;   // penghitung kebocoran suara asli / suara mati (lihat _watch)
    }

    configure(c) {
      if (!c) return;
      if (typeof c.f0 === 'number') this.P.f0 = clamp(c.f0, 100, 600);
      if (typeof c.formant === 'number') this.P.formant = clamp(c.formant, 0.85, 1.6);
      if (typeof c.inton === 'number') this.P.inton = clamp(c.inton, 0, 2);
      if (typeof c.tune === 'number') this.P.tune = clamp(c.tune, -15, 15);
      if (typeof c.active === 'boolean') this.mixTarget = c.active ? 1 : 0;
      if (typeof c.autoHeal === 'boolean') this.autoHeal = c.autoHeal;
      if (c.refresh && !this.idle) this._hardReset();   // refresh mode: mulai bersih seperti pindah Normal lalu balik
      if (typeof c.delay === 'number') {
        const L = Math.max(this.LqMin, Math.round(clamp(c.delay, 0, 500) / 1000 * this.sr));
        if (L !== this.Lq) { this.Lq = L; if (!this.idle) this._reset(); }
      }
    }

    // ---------------------------------------------------------------- utama
    process(inp, out) {
      const N = out.length;
      const n0 = this.n;
      const active = this.mixTarget > 0 || this.mix > 0;
      if (active && this.idle) this._wake();

      // 1) masukkan sampel, jalankan analisis tiap HOP
      let pos = 0;
      while (pos < N) {
        const take = Math.min(N - pos, HOP - (this.n & (HOP - 1)));
        for (let i = 0; i < take; i++) this._push(inp ? inp[pos + i] : 0);
        pos += take;
        if ((this.n & (HOP - 1)) === 0 && !this.idle) this._analyze();
      }

      // 2) sintesis sampai semua keluaran blok ini final
      if (!this.idle) {
        const nEnd = this.n;
        // sembuh sendiri kalau posisi sintesis kacau (NaN / ketinggalan jauh / kejauhan)
        const lag = (nEnd - this.Lq) - this.ts;
        if (!(lag === lag) || (this.autoHeal && (lag > 0.15 * this.sr || lag < -4 * this.HW))) { this.stat.heal++; this._hardReset(); }
        this._synth(nEnd - this.Lq + this.HW);
      }

      // 3) tulis keluaran
      const e0 = n0 - this.Lq;
      let sOO = 0, sRR = 0, sOR = 0;
      for (let i = 0; i < N; i++) {
        const dry = inp ? inp[i] : 0;
        let y = dry;
        if (!this.idle) {
          const j = (e0 + i) & RM;
          const wet = (e0 + i) >= 0 ? this.ob[j] : 0;
          this.ob[j] = 0;
          if (this.mix < this.mixTarget) this.mix = Math.min(this.mixTarget, this.mix + this.mixStep);
          else if (this.mix > this.mixTarget) this.mix = Math.max(this.mixTarget, this.mix - this.mixStep);
          y = dry + (wet - dry) * this.mix;
          if (!(y === y) || y > 1e4 || y < -1e4) { y = 0; this._reset(); }
          const ay = y < 0 ? -y : y;
          if (ay > 0.8) y = (y < 0 ? -1 : 1) * (0.8 + 0.2 * Math.tanh((ay - 0.8) / 0.2));
          if (this.muteN > 0) { this.muteN--; y = 0; }
          const rw = (e0 + i) >= 0 ? this.xr[j] : 0;   // masukan asli yang ditunda, pembanding kebocoran
          sOO += y * y; sRR += rw * rw; sOR += y * rw;
        }
        out[i] = y;
      }
      if (!this.idle) {
        this.emitted = e0 + N;
        if (this.mix === 0 && this.mixTarget === 0) this.idle = true;
        else this._watch(sOO, sRR, sOR, N);
      }
    }

    // Deteksi kebocoran: masukan jelas bernada + sudah seharusnya dinaikkan, tapi keluaran = masukan asli (korelasi tinggi)
    // terus-menerus ~160 ms, atau keluaran hening padahal masukan keras ~200 ms -> refresh mesin otomatis.
    _watch(sOO, sRR, sOR, N) {
      if (!this.autoHeal || this.mixTarget < 1 || this.mix < 0.99) { this.leakN = 0; this.deadN = 0; return; }
      const rIn = Math.sqrt(sRR / N), rOut = Math.sqrt(sOO / N);
      if (rIn < 0.01) { if (this.leakN > 0) this.leakN--; if (this.deadN > 0) this.deadN--; return; }
      const rho = sOR / Math.sqrt(sOO * sRR + 1e-12), st = this.stat;
      const shifted = st.f0in > 0 && Math.abs(LN(st.f0out / st.f0in)) > 0.15;
      if (rho > 0.92 && this.lastClarity >= 0.75 && shifted) this.leakN++; else this.leakN = Math.max(0, this.leakN - 2);
      if (rOut < 0.05 * rIn) this.deadN++; else this.deadN = Math.max(0, this.deadN - 2);
      if (this.leakN > 60 || this.deadN > 80) { st.heal++; this._hardReset(); }
    }

    // refresh penuh: bersihkan semua keadaan analisis/sintesis (nada rata-rata pembicara dipertahankan)
    _hardReset() {
      this.hx1 = this.hx2 = this.hy1 = this.hy2 = this.lx1 = this.lx2 = this.ly1 = this.ly2 = 0;
      this.fTag.fill(-1); this.fV.fill(0);
      if (!isFinite(this.mu)) { this.mu = LN(125); this.muN = 0; }
      this.lnT = LN(this.sr / 120); this.accD = 0; this.cntD = 0;
      this.leakN = 0; this.deadN = 0;
      this.muteN = Math.round(0.05 * this.sr);
      this._wake();
    }

    _wake() {
      this.idle = false;
      this.ob.fill(0);
      this.ts = this.n - this.Lq;
      this.emitted = this.ts;
      this.trk.active = false;
      this.vs = false; this.vc = 0; this.uc = 0; this.Tprev = 0; this.hn = 0;
      this.kLast = Math.floor(this.n / HOP) - 1;
      this.mptr = this.mcount;
    }

    _reset() {
      this.ob.fill(0);
      this.ts = this.n - this.Lq; this.emitted = this.ts;
      this.trk.active = false; this.vs = false; this.vc = 0; this.uc = 0; this.Tprev = 0; this.hn = 0;
      this.hx1 = this.hx2 = this.hy1 = this.hy2 = this.lx1 = this.lx2 = this.ly1 = this.ly2 = 0;
    }

    _push(x) {
      if (!(x === x)) x = 0;
      const i = this.n & RM;
      this.xr[i] = x;
      // highpass 1-kutub lalu lowpass biquad
      const h = this.hb0 * x + this.hb1 * this.hx1 + this.hb2 * this.hx2 - this.ha1 * this.hy1 - this.ha2 * this.hy2;
      this.hx2 = this.hx1; this.hx1 = x; this.hy2 = this.hy1; this.hy1 = h;
      const y = this.lb0 * h + this.lb1 * this.lx1 + this.lb2 * this.lx2 - this.la1 * this.ly1 - this.la2 * this.ly2;
      this.lx2 = this.lx1; this.lx1 = h; this.ly2 = this.ly1; this.ly1 = y;
      this.xl[i] = y;
      this.accD += y;
      if (++this.cntD === this.D) { this.xd[this.nd & RM] = this.accD / this.D; this.nd++; this.accD = 0; this.cntD = 0; }
      this.n++;
    }

    // ---------------------------------------------------------------- analisis nada
    _analyze() {
      const k = this.n / HOP;
      const W = this.W, tauMax = this.tauMax, tauMin = this.tauMin, D = this.D;
      const need = W + tauMax;
      const seg = this.seg, nsdf = this.nsdf;
      let cand = null, rmsB = 0;
      if (this.nd >= need + 4) {
        const st = this.nd - need;
        for (let i = 0; i < need; i++) seg[i] = this.xd[(st + i) & RM];
        let eB = 0;
        for (let j = 0; j < W; j++) { const v = seg[tauMax + j]; eB += v * v; }
        rmsB = Math.sqrt(eB / W);
        let eA = 0;
        { const b = tauMax - tauMin; for (let j = 0; j < W; j++) { const v = seg[b + j]; eA += v * v; } }
        for (let tau = tauMin; tau <= tauMax; tau++) {
          const b = tauMax - tau;
          if (tau > tauMin) { const a = seg[b], r = seg[b + W]; eA += a * a - r * r; }
          let dot = 0;
          for (let j = 0; j < W; j++) dot += seg[b + j] * seg[tauMax + j];
          nsdf[tau] = 2 * dot / (eA + eB + 1e-12);
        }
        cand = rmsB > 0.0007 ? this._pickPeak() : null;
      }

      // keputusan bersuara / tidak (dengan histeresis)
      const thr = this.vs ? V_STAY : V_ENTER;
      let ok = !!cand && cand.v >= thr;
      // kejernihan rendah (derau) hanya diterima kalau nadanya nyambung dengan nada sebelumnya
      if (ok && this.vs && this.Tprev > 0) {
        const dj = Math.abs(LN(cand.tau * D / this.Tprev));
        if ((cand.v < V_SURE && dj > 0.15) || (cand.v < 0.8 && dj > 0.35)) ok = false;   // lompatan nada mencurigakan (salah oktaf)
      }
      this.lastClarity = cand ? cand.v : 0;
      if (ok) { this.vc++; this.uc = 0; } else { this.uc++; this.vc = 0; }
      let entering = false;
      if (!this.vs && this.vc >= 2) { this.vs = true; entering = true; this.run++; }
      else if (this.vs && this.uc >= V_HANG) { this.vs = false; this.Tprev = 0; }

      if (ok) {
        const lt = LN(cand.tau * D);
        if (entering) { this.hist[0] = this.hist[1] = this.hist[2] = lt; this.lnT = lt; }
        else { this.hist[0] = this.hist[1]; this.hist[1] = this.hist[2]; this.hist[2] = lt; }
        const a = this.hist[0], b = this.hist[1], c = this.hist[2];
        const med = Math.max(Math.min(a, b), Math.min(Math.max(a, b), c));
        this.lnT += (entering ? 1 : 0.4) * (med - this.lnT);
        this.lnT = clamp(this.lnT, LN(this.sr / 500), LN(this.Tmax));
        this.Tprev = Math.exp(this.lnT);
        // belajar rata-rata nada pembicara
        if (this.vs && cand.v >= 0.6) {
          const lf = LN(this.sr) - this.lnT;
          if (Math.abs(lf - this.mu) < 0.6) {
            this.muN++;
            this.mu += (lf - this.mu) / Math.min(4 + this.muN, 3000);
          }
        }
      }

      const T = this.Tprev || Math.exp(this.lnT);
      const slot = k & FM;
      this.fTag[slot] = k; this.fV[slot] = this.vs ? 1 : 0; this.fT[slot] = T; this.fRun[slot] = this.run;
      this.kLast = k;
      this.stat.voiced = this.vs ? 1 : 0;
      if (this.vs) { this.stat.f0in = this.sr / T; this.stat.f0out = this.stat.f0in * this._ratio(T); }

      this._track(this.n - this.dc, T, this.vs, entering);
    }

    _pickPeak() {
      const nsdf = this.nsdf, tauMin = this.tauMin, tauMax = this.tauMax;
      // puncak kunci: maksimum tiap daerah positif setelah lintasan nol ke bawah
      const keysT = this._kT || (this._kT = new Float32Array(32));
      const keysV = this._kV || (this._kV = new Float32Array(32));
      let nk = 0, tau = tauMin;
      while (tau < tauMax && nsdf[tau] > 0) tau++;
      while (tau < tauMax && nk < 32) {
        while (tau < tauMax && nsdf[tau] <= 0) tau++;
        let pk = -1, pv = -1;
        while (tau < tauMax && nsdf[tau] > 0) { if (nsdf[tau] > pv) { pv = nsdf[tau]; pk = tau; } tau++; }
        if (pk > tauMin && pk < tauMax - 1) {
          const a = nsdf[pk - 1], b = nsdf[pk], c = nsdf[pk + 1];
          const den = a - 2 * b + c;
          const off = den < -1e-9 ? 0.5 * (a - c) / den : 0;
          keysT[nk] = pk + clamp(off, -1, 1);
          keysV[nk] = b - 0.25 * (a - c) * off;
          nk++;
        }
      }
      if (!nk) return null;
      let vmax = 0;
      for (let i = 0; i < nk; i++) if (keysV[i] > vmax) vmax = keysV[i];
      if (this.vs && this.Tprev > 0) {
        let li = -1, lv = -1;
        for (let i = 0; i < nk; i++) {
          if (Math.abs(LN(keysT[i] * this.D / this.Tprev)) < 0.12 && keysV[i] > lv) { lv = keysV[i]; li = i; }
        }
        if (li >= 0 && lv >= 0.7 * vmax) return { tau: keysT[li], v: lv };
      }
      const lim = 0.72 * vmax;
      let bi = -1, bd = 1e9;
      for (let i = 0; i < nk; i++) {
        if (keysV[i] < lim) continue;
        if (this.vs && this.Tprev > 0) {
          const d = Math.abs(LN(keysT[i] * this.D / this.Tprev));
          if (d < bd) { bd = d; bi = i; }
        } else { bi = i; break; }   // tanpa riwayat: ambil periode terpendek yang cukup kuat
      }
      if (bi < 0) return null;
      return { tau: keysT[bi], v: keysV[bi] };
    }

    // ---------------------------------------------------------------- pitch mark
    _track(c, T, voiced, entering) {
      const trk = this.trk;
      if (!voiced) { trk.active = false; return; }
      const xl = this.xl;
      if (entering || !trk.active) {
        const a = Math.floor(c - T), b = Math.floor(c);
        if (a <= this.n - RING + 64) return;
        let mx = -1e9, mn = 1e9, imx = a, imn = a;
        for (let q = a; q <= b; q++) {
          const v = xl[q & RM];
          if (v > mx) { mx = v; imx = q; }
          if (v < mn) { mn = v; imn = q; }
        }
        trk.pol = mx >= -mn ? 1 : -1;
        trk.last = trk.pol > 0 ? imx : imn;
        trk.active = true;
        this._pushMark(trk.last, T);
      }
      let guard = 0;
      while (guard++ < 8) {
        const pred = trk.last + T;
        if (pred > c + HOP) break;
        const q = this._findNext(trk.last, T, pred, trk.pol);
        if (q < 0) break;
        trk.last = q;
        this._pushMark(q, T);
      }
    }

    _pushMark(pos, T) {
      const i = this.mcount & MM;
      this.mPos[i] = pos; this.mPer[i] = T; this.mRun[i] = this.run;
      this.mcount++;
    }

    _findNext(last, T, pred, pol) {
      const xl = this.xl;
      const h = clamp(Math.floor(0.3 * T), 8, 1000);
      const range = Math.max(4, Math.floor(0.25 * T));
      const pr = Math.round(pred);
      const lo = pr - range, hi = pr + range;
      if (hi + h + 2 >= this.n || last - h - 2 <= this.n - RING + 64) return -1;
      const ref = this.ref;
      let er = 0;
      for (let j = -h; j <= h; j++) { const v = xl[(last + j) & RM]; ref[j + h] = v; er += v * v; }
      if (er < 1e-12) return pr;
      const score = (q) => {
        let dot = 0, ec = 0;
        for (let j = -h; j <= h; j++) { const v = xl[(q + j) & RM]; dot += ref[j + h] * v; ec += v * v; }
        const d = (q - pr) / range;
        return dot / Math.sqrt(er * ec + 1e-12) - 0.15 * d * d;
      };
      let best = -9, bq = pr;
      for (let q = lo; q <= hi; q += 2) { const s = score(q); if (s > best) { best = s; bq = q; } }
      for (let q = bq - 1; q <= bq + 1; q += 2) { if (q < lo || q > hi) continue; const s = score(q); if (s > best) { best = s; bq = q; } }
      // tempelkan ke puncak lokal terdekat supaya tidak melenceng pelan-pelan
      const sn = Math.max(2, Math.round(0.12 * T));
      let pk = bq, pv = pol * xl[bq & RM];
      for (let q = bq - sn; q <= bq + sn; q++) { const v = pol * xl[q & RM]; if (v > pv) { pv = v; pk = q; } }
      if (pk <= last + 0.5 * T) pk = Math.round(last + T);
      return pk;
    }

    // ---------------------------------------------------------------- sintesis
    _ratio(T) {
      const P = this.P;
      const F0 = this.sr / T;
      const target = P.f0 * Math.pow(2, P.tune / 12);
      const lo = clamp(LN(target) + P.inton * (LN(F0) - this.mu), LN(60), LN(1000));
      return clamp(Math.exp(lo) / F0, 0.45, 6);
    }

    _nearestMark(ts, run, T) {
      if (this.mcount === 0) return -1;
      const lowest = Math.max(0, this.mcount - MRING + 4);
      let i = clamp(this.mptr, lowest, this.mcount - 1);
      const mp = this.mPos;
      while (i + 1 < this.mcount && Math.abs(mp[(i + 1) & MM] - ts) <= Math.abs(mp[i & MM] - ts)) i++;
      while (i - 1 >= lowest && Math.abs(mp[(i - 1) & MM] - ts) < Math.abs(mp[i & MM] - ts)) i--;
      this.mptr = i;
      if (this.mRun[i & MM] !== run) return -1;
      if (Math.abs(mp[i & MM] - ts) > 0.8 * T) return -1;
      return i;
    }

    _synth(tsLimit) {
      let guard = 0;
      while (this.ts < tsLimit && guard++ < 200) {
        const ts = this.ts;
        const kf = Math.floor((ts + this.dc) / HOP);
        let voiced = false, T = 0, run = -1;
        if (kf <= this.kLast && kf > this.kLast - FRING + 8 && this.fTag[kf & FM] === kf) {
          voiced = this.fV[kf & FM] === 1; T = this.fT[kf & FM]; run = this.fRun[kf & FM];
        } else if (ts + this.dc > this.n) {
          this.stat.underrun++;
        }
        if (voiced) {
          const mi = this._nearestMark(ts, run, T);
          if (mi >= 0) {
            const m = this.mPos[mi & MM];
            const Tm = this.mPer[mi & MM];
            const f = this.P.formant, p = this._ratio(T);
            const Hin = Math.round(Math.min(Tm, T * 1.25));
            const Hout = Math.min(this.HW, Math.max(8, Math.round(Hin / f)));
            if (m + Hin + 4 < this.n && m - Hin - 4 > this.n - RING + 64) {
              this._grain(ts, m, Hout, f, 1.15 * Math.sqrt(f / p));
              this.ts = ts + T / p;
              continue;
            }
          }
        }
        if (voiced) {   // bersuara tapi pitch mark hilang: tetap diubah (grain di posisi sekarang), jangan lolos suara asli
          const f = this.P.formant, p = this._ratio(T), Hin = Math.round(Math.min(T, this.HW));
          const Hout = Math.min(this.HW, Math.max(8, Math.round(Hin / f))), c = Math.round(ts);
          if (c + Hin + 4 < this.n && c - Hin - 4 > this.n - RING + 64) {
            this._grain(ts, c, Hout, f, 1.15 * Math.sqrt(f / p));
            this.ts = ts + T / p;
            continue;
          }
        }
        // jalur aman: grain identitas (keluaran = masukan yang ditunda)
        const H = voiced ? Math.min(this.HW, Math.max(16, Math.round(T))) : this.Hu;
        this._grain(ts, ts, H, 1, 1);
        this.ts = ts + H;
      }
    }

    _grain(ts, src, H, f, gain) {
      const ti = Math.floor(ts), fr = ts - ti;
      const xr = this.xr, ob = this.ob, pi = Math.PI / (H + 1);
      const lowIdx = this.n - RING + 8;
      const first = Math.max(-H, this.emitted - ti);
      for (let k = first; k <= H; k++) {
        const w = 0.5 + 0.5 * Math.cos(pi * k);
        const r = src + (k - fr) * f;
        const i0 = Math.floor(r);
        if (i0 + 2 >= this.n || i0 - 1 < lowIdx) continue;
        const u = r - i0;
        const a = xr[(i0 - 1) & RM], b = xr[i0 & RM], c = xr[(i0 + 1) & RM], d = xr[(i0 + 2) & RM];
        const s = b + 0.5 * u * (c - a + u * (2 * a - 5 * b + 4 * c - d + u * (3 * (b - c) + d - a)));
        ob[(ti + k) & RM] += gain * w * s;
      }
    }
  }

  const api = { VoiceEngine, HOP };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.VoiceEngine = VoiceEngine;

  // ---- AudioWorklet ----
  if (typeof registerProcessor === 'function' && typeof AudioWorkletProcessor !== 'undefined') {
    class VoiceChanger extends AudioWorkletProcessor {
      constructor() {
        super();
        this.eng = new VoiceEngine(sampleRate);
        this.tick = 0;
        this.port.onmessage = (e) => this.eng.configure(e.data);
      }
      process(inputs, outputs) {
        const o = outputs[0] && outputs[0][0];
        if (!o) return true;
        const i = inputs[0] && inputs[0][0];
        try { this.eng.process(i || null, o); } catch (err) { o.fill(0); this.eng.stat.heal++; try { this.eng._hardReset(); } catch (e2) { this.eng._reset(); } }
        if (++this.tick >= 100) {            // ~ tiap 270 ms kirim info ke UI
          this.tick = 0;
          const s = this.eng.stat;
          this.port.postMessage({ f0in: s.voiced ? s.f0in : 0, f0out: s.voiced ? s.f0out : 0, mu: Math.exp(this.eng.mu), heal: this.eng.stat.heal });
        }
        return true;
      }
    }
    registerProcessor('voice-changer', VoiceChanger);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
