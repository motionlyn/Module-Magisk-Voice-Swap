// Tes ketahanan: blok acak, hening, derau, NaN, clipping, ganti parameter sambil jalan, sr aneh.
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
#include "../native/src/engine.hpp"
int main() {
  std::mt19937 g(1); std::uniform_real_distribution<float> u(-1, 1);
  int bad = 0; long total = 0;
  for (int sr : {8000, 11025, 16000, 22050, 24000, 44100, 48000}) {
    mlv::VoiceEngine e(sr);
    mlv::Params p; p.rel = true; p.relSemi = 11; p.formant = 1.18; p.inton = 1.1; e.setParams(p); e.setActive(true);
    std::vector<float> in(8192), out(8192);
    for (int it = 0; it < 250; it++) {
      int n = 1 + g() % 4096; int mode = g() % 7;
      for (int i = 0; i < n; i++) {
        float t = (float)(total + i) / sr;
        switch (mode) {
          case 0: in[i] = 0; break;
          case 1: in[i] = u(g) * 0.5f; break;
          case 2: in[i] = 0.4f * std::sin(6.283f * 130 * t) + 0.2f * std::sin(6.283f * 390 * t); break;
          case 3: in[i] = (g() % 50 == 0) ? NAN : 0.1f; break;
          case 4: in[i] = (g() % 2 ? 1 : -1) * 50.f; break;
          case 5: in[i] = 0.3f * std::sin(6.283f * (80 + 400 * std::fmod(t, 1.f)) * t); break;
          default: in[i] = INFINITY * (g() % 7 == 0 ? 1 : 0) + 0.2f * u(g);
        }
      }
      if (it % 40 == 0) { p.relSemi = (float)(g() % 25) - 12; p.formant = 0.9 + (g() % 60) / 100.0; e.setParams(p); }
      if (it % 60 == 7) e.setDelayMs((double)(g() % 200));
      if (it % 90 == 9) e.refresh();
      if (it % 110 == 11) e.setActive(g() % 2);
      e.process(g() % 5 ? in.data() : nullptr, out.data(), n);
      for (int i = 0; i < n; i++) if (!std::isfinite(out[i]) || std::fabs(out[i]) > 8.01f) { bad++; break; }
      total += n;
    }
    printf("sr=%d ok, heal=%d\n", sr, e.stat().heal);
  }
  printf("blok dengan keluaran tak valid: %d dari ~%ld sampel\n", bad, total);
  return bad != 0;
}
