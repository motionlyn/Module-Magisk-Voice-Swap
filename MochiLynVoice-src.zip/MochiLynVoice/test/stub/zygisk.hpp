// STUB hanya untuk cek sintaks di host. ABI asli ada di zygisk.hpp resmi (diunduh saat build).
#pragma once
#include <jni.h>
namespace zygisk {
enum class Option { DLCLOSE_MODULE_LIBRARY = 1 };
struct AppSpecializeArgs { jint& uid; jstring& nice_name; };
struct ServerSpecializeArgs {};
struct Api {
  int connectCompanion(); void setOption(Option);
  void hookJniNativeMethods(JNIEnv*, const char*, JNINativeMethod*, int);
};
struct ModuleBase {
  virtual ~ModuleBase() {}
  virtual void onLoad(Api*, JNIEnv*) {}
  virtual void preAppSpecialize(AppSpecializeArgs*) {}
  virtual void postAppSpecialize(const AppSpecializeArgs*) {}
  virtual void preServerSpecialize(ServerSpecializeArgs*) {}
};
}
#define REGISTER_ZYGISK_MODULE(clazz) void* zygisk_module_entry_stub = new clazz;
#define REGISTER_ZYGISK_COMPANION(func) void* zygisk_companion_entry_stub = (void*)func;
