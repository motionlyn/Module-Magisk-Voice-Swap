// STUB hanya untuk cek sintaks di host (bukan jni.h asli). Build Android memakai jni.h dari NDK.
#pragma once
#include <cstdint>
#include <cstddef>
typedef int32_t jint; typedef uint8_t jboolean; typedef int8_t jbyte; typedef int16_t jshort; typedef float jfloat; typedef int32_t jsize;
class _jobject {}; typedef _jobject* jobject; typedef jobject jclass; typedef jobject jstring; typedef jobject jarray;
typedef jarray jbyteArray; typedef jarray jshortArray; typedef jarray jfloatArray;
struct _jmethodID; typedef _jmethodID* jmethodID;
struct JNINativeMethod { char* name; char* signature; void* fnPtr; };
struct JNIEnv {
  jclass FindClass(const char*); jmethodID GetMethodID(jclass, const char*, const char*); jmethodID GetStaticMethodID(jclass, const char*, const char*);
  jobject NewGlobalRef(jobject); jint CallIntMethod(jobject, jmethodID, ...); jint CallStaticIntMethod(jclass, jmethodID, ...);
  jboolean ExceptionCheck(); void ExceptionClear();
  void GetByteArrayRegion(jbyteArray, jsize, jsize, jbyte*); void SetByteArrayRegion(jbyteArray, jsize, jsize, const jbyte*);
  void GetShortArrayRegion(jshortArray, jsize, jsize, jshort*); void SetShortArrayRegion(jshortArray, jsize, jsize, const jshort*);
  void GetFloatArrayRegion(jfloatArray, jsize, jsize, jfloat*); void SetFloatArrayRegion(jfloatArray, jsize, jsize, const jfloat*);
  void* GetDirectBufferAddress(jobject);
  const char* GetStringUTFChars(jstring, jboolean*); void ReleaseStringUTFChars(jstring, const char*);
};
