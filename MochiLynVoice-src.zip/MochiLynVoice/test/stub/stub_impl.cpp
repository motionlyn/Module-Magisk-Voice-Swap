// Implementasi kosong untuk stub JNI/Zygisk (hanya untuk tes host).
#include <jni.h>
#include <android/log.h>
#include "zygisk.hpp"
jclass JNIEnv::FindClass(const char*) { return nullptr; }
jmethodID JNIEnv::GetMethodID(jclass, const char*, const char*) { return nullptr; }
jmethodID JNIEnv::GetStaticMethodID(jclass, const char*, const char*) { return nullptr; }
jobject JNIEnv::NewGlobalRef(jobject o) { return o; }
jint JNIEnv::CallIntMethod(jobject, jmethodID, ...) { return 0; }
jint JNIEnv::CallStaticIntMethod(jclass, jmethodID, ...) { return 0; }
jboolean JNIEnv::ExceptionCheck() { return 0; }
void JNIEnv::ExceptionClear() {}
void JNIEnv::GetByteArrayRegion(jbyteArray, jsize, jsize, jbyte*) {}
void JNIEnv::SetByteArrayRegion(jbyteArray, jsize, jsize, const jbyte*) {}
void JNIEnv::GetShortArrayRegion(jshortArray, jsize, jsize, jshort*) {}
void JNIEnv::SetShortArrayRegion(jshortArray, jsize, jsize, const jshort*) {}
void JNIEnv::GetFloatArrayRegion(jfloatArray, jsize, jsize, jfloat*) {}
void JNIEnv::SetFloatArrayRegion(jfloatArray, jsize, jsize, const jfloat*) {}
void* JNIEnv::GetDirectBufferAddress(jobject) { return nullptr; }
const char* JNIEnv::GetStringUTFChars(jstring, jboolean*) { return nullptr; }
void JNIEnv::ReleaseStringUTFChars(jstring, const char*) {}
int zygisk::Api::connectCompanion() { return -1; }
void zygisk::Api::setOption(zygisk::Option) {}
void zygisk::Api::hookJniNativeMethods(JNIEnv*, const char*, JNINativeMethod*, int) {}
extern "C" int __android_log_print(int, const char*, const char*, ...) { return 0; }
