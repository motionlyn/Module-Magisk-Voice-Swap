#!/usr/bin/env bash
# Tes host (tanpa Android): paritas C++ vs JS, fuzz ASan/UBSan, logika modul, skrip mlv.
set -euo pipefail
cd "$(dirname "$0")"
g++ -O2 -std=c++17 -Wall -Wextra -o test_engine test_engine.cpp
for SR in 48000 16000; do
  python3 make_signal.py $SR in_$SR.f32
  ./test_engine in_$SR.f32 cpp_$SR.f32 $SR 128 205 1.18 1.1 0 45 2>/dev/null
  node ref.js in_$SR.f32 js_$SR.f32 $SR 128 205 1.18 1.1 0 45 2>/dev/null
  echo "== paritas sr=$SR =="; python3 compare.py cpp_$SR.f32 js_$SR.f32 $SR in_$SR.f32
done
g++ -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined -std=c++17 -o fuzz_asan fuzz.cpp && ./fuzz_asan | tail -2
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -DMLV_DIR='"/tmp/mlv_test"' -Wno-unused-parameter -Wno-unused-result \
    -Istub -I../native/src -o test_module test_module.cpp stub/stub_impl.cpp -lpthread
./test_module | tail -3
