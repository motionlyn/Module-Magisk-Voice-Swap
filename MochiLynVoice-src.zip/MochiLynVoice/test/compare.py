import numpy as np, sys
a = np.fromfile(sys.argv[1], dtype=np.float32); b = np.fromfile(sys.argv[2], dtype=np.float32)
sr = int(sys.argv[3]); orig = np.fromfile(sys.argv[4], dtype=np.float32)
n = min(len(a), len(b))
d = a[:n] - b[:n]
rel = np.sqrt(np.mean(d**2)) / (np.sqrt(np.mean(b[:n]**2)) + 1e-12)
corr = np.corrcoef(a[:n], b[:n])[0, 1]
print(f'C++ vs JS: korelasi={corr:.5f}  selisih relatif RMS={rel:.5f}  maks|selisih|={np.max(np.abs(d)):.4f}')
def f0(x, lo=70, hi=500):
    fr = int(0.04 * sr); hop = int(0.02 * sr); res = []
    for s in range(int(0.3 * sr), len(x) - fr, hop):
        w = x[s:s + fr] * np.hanning(fr)
        if np.sqrt(np.mean(w**2)) < 0.01: continue
        ac = np.correlate(w, w, 'full')[fr - 1:]; ac /= ac[0] + 1e-12
        l, h = int(sr / hi), int(sr / lo)
        k = l + np.argmax(ac[l:h])
        if ac[k] > 0.5: res.append(sr / k)
    return np.array(res)
fi, fo = f0(orig), f0(a)
print(f'nada masuk median={np.median(fi):.1f} Hz | nada keluar C++ median={np.median(fo):.1f} Hz (p10={np.percentile(fo,10):.0f}, p90={np.percentile(fo,90):.0f})')
fj = f0(b); print(f'nada keluar JS  median={np.median(fj):.1f} Hz')
print('NaN/Inf di keluaran C++:', int(np.sum(~np.isfinite(a))), '| puncak', float(np.max(np.abs(a))))
