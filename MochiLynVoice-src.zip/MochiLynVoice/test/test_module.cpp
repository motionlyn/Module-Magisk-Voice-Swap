// Tes logika modul di host (tanpa Android): protokol companion, config/preset, pencocokan app, dan jalur PCM16.
#include <sys/wait.h>
#include <thread>
#include <cassert>
#include "../native/src/main.cpp"   // sengaja include langsung supaya fungsi static bisa dites

static void writeFile(const std::string& p, const std::string& s) { FILE* f = fopen(p.c_str(), "w"); fputs(s.c_str(), f); fclose(f); }
static Msg ask(int fd, const char* proc, int uid) {
  uint32_t len = strlen(proc); writen(fd, &len, 4); writen(fd, proc, len); writen(fd, &uid, 4);
  Msg m; assert(readn(fd, &m, sizeof m)); return m;
}
int main() {
  int fails = 0;
  auto check = [&](bool c, const char* what) { printf("%s %s\n", c ? "[ok]  " : "[GAGAL]", what); if (!c) fails++; };
  system("rm -rf " MLV_DIR " && mkdir -p " MLV_DIR);
  writeFile(std::string(kDir) + "/apps.txt", "# daftar\ncom.whatsapp\ncom.roblox.client\n");
  writeFile(std::string(kDir) + "/config.txt", "preset=plus11\ntune=1.5\ndelay=60\n");

  struct { const char* p; int uid; bool want; } cases[] = {
    {"com.whatsapp", 10120, true}, {"com.whatsapp:voip", 10120, true}, {"com.whatsapp.w4b", 10120, false},
    {"com.roblox.client", 10300, true}, {"com.android.chrome", 10050, false}, {"com.whatsapp", 1000, false}};
  for (auto& c : cases) {
    int sv[2]; socketpair(AF_UNIX, SOCK_STREAM, 0, sv);
    std::thread t(companionHandler, sv[1]);
    Msg m = ask(sv[0], c.p, c.uid);
    char b[120]; snprintf(b, sizeof b, "app %s uid %d -> enabled=%d (harus %d)", c.p, c.uid, m.enabled, c.want);
    check(m.enabled == c.want, b);
    if (c.want && strcmp(c.p, "com.whatsapp") == 0 && c.uid == 10120) {
      check(m.magic == kMagic && m.rel == 1 && m.relSemi == 11 && m.active == 1 && m.tune == 1.5f && m.delay == 60, "config plus11 + tune 1.5 + delay 60 terbaca");
      writeFile(std::string(kDir) + "/config.txt", "preset=anime\nrefresh=3\n");
      char cmd = 'C'; writen(sv[0], &cmd, 1); Msg m2; readn(sv[0], &m2, sizeof m2);
      check(m2.rel == 0 && m2.f0 == 250 && m2.refreshN == 3 && m2.delay == 45 && m2.tune == 0, "ganti preset ke anime berlaku di polling berikutnya");
      writeFile(std::string(kDir) + "/config.txt", "preset=normal\n");
      writen(sv[0], &cmd, 1); readn(sv[0], &m2, sizeof m2);
      check(m2.active == 0, "preset normal -> active=0");
      writeFile(std::string(kDir) + "/config.txt", "preset=ngawur\nenabled=0\n");
      writen(sv[0], &cmd, 1); readn(sv[0], &m2, sizeof m2);
      check(m2.active == 0, "enabled=0 mematikan efek; preset tak dikenal tidak membuat crash");
      std::string info = "tes hit"; uint32_t len = info.size(); char h = 'H';
      writen(sv[0], &h, 1); writen(sv[0], &len, 4); writen(sv[0], info.data(), len);
      writeFile(std::string(kDir) + "/config.txt", "preset=plus11\n");
      writen(sv[0], &cmd, 1); readn(sv[0], &m2, sizeof m2);   // memastikan 'H' sudah diproses
      FILE* f = fopen((std::string(kDir) + "/status/com.whatsapp.txt").c_str(), "r");
      char line[100] = ""; if (f) { fgets(line, sizeof line, f); fclose(f); }
      check(strncmp(line, "tes hit", 7) == 0, "laporan hook ('H') ditulis ke status/");
    }
    close(sv[0]); t.join();
  }
  // config rusak / kosong
  writeFile(std::string(kDir) + "/config.txt", "\n\nsampah tanpa sama dengan\ntune=abc\n");
  Msg d = loadConfig(); check(d.active == 1 && d.rel == 1 && d.delay == 45, "config rusak -> pakai bawaan plus11");

  // jalur PCM16: suara cowok sintetis masuk -> nada naik ~+11 semitone
  g_msg = loadConfig(); g_msg.enabled = 1; g_msg.active = 1; g_msg.delay = 45;
  Slot s; s.sr = 16000; s.ch = 1; s.fmt = 2; s.eng.reset(new mlv::VoiceEngine(16000));
  FILE* fi = fopen("in_16000.f32", "rb"); std::vector<float> in(16000 * 7); size_t got = fread(in.data(), 4, in.size(), fi); fclose(fi); in.resize(got);
  std::vector<int16_t> pcm(in.size()), orig;
  for (size_t i = 0; i < in.size(); i++) pcm[i] = (int16_t)(in[i] * 32767);
  orig = pcm; applyConfig(&s);
  for (size_t i = 0; i + 320 <= pcm.size(); i += 320) processBuffer<int16_t>(&s, pcm.data() + i, 320);
  FILE* fo = fopen("pcm_out.f32", "wb"); std::vector<float> o(pcm.size()); for (size_t i = 0; i < o.size(); i++) o[i] = pcm[i] / 32768.f; fwrite(o.data(), 4, o.size(), fo); fclose(fo);
  size_t changed = 0; for (size_t i = 0; i < pcm.size(); i++) changed += pcm[i] != orig[i];
  check(changed > pcm.size() / 2, "jalur PCM16 mengubah data");
  // stereo: kedua kanal sama setelah diproses
  Slot s2; s2.sr = 48000; s2.ch = 2; s2.fmt = 2; s2.eng.reset(new mlv::VoiceEngine(48000)); applyConfig(&s2);
  std::vector<int16_t> st(2 * 4800); for (size_t i = 0; i < st.size() / 2; i++) { st[2*i] = (int16_t)(8000 * sin(i * 0.05)); st[2*i+1] = st[2*i]; }
  for (int k = 0; k < 20; k++) processBuffer<int16_t>(&s2, st.data(), 4800);
  bool same = true; for (size_t i = 0; i < st.size() / 2; i++) same &= st[2*i] == st[2*i+1];
  check(same, "stereo: dua kanal konsisten");
  printf(fails ? "\n%d tes GAGAL\n" : "\nsemua tes lolos\n", fails);
  return fails != 0;
}
