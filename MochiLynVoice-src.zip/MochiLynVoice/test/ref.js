// Referensi: jalankan mesin JS asli (voice-processor.js) pada file float32 yang sama.
// pemakaian: node ref.js in.f32 out.f32 sr block f0 formant inton tune delay_ms
const fs = require('fs');
const { VoiceEngine } = require('./voice-processor.js');
const [,, fin, fout, sr, blk, f0, formant, inton, tune, delay] = process.argv;
const raw = fs.readFileSync(fin);
const inp = new Float32Array(raw.buffer, raw.byteOffset, raw.length / 4);
const out = new Float32Array(inp.length);
const e = new VoiceEngine(+sr);
e.configure({ f0: +f0, formant: +formant, inton: +inton, tune: +tune, delay: +delay, active: true });
const B = +blk;
for (let i = 0; i < inp.length; i += B) {
  const n = Math.min(B, inp.length - i);
  e.process(inp.subarray(i, i + n), out.subarray(i, i + n));
}
fs.writeFileSync(fout, Buffer.from(out.buffer));
console.error('heal=' + e.stat.heal + ' underrun=' + e.stat.underrun + ' speakerF0=' + Math.exp(e.mu).toFixed(1));
