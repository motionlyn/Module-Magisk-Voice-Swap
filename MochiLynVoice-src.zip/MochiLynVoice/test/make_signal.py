# Sinyal uji mirip suara cowok: nada 105-135 Hz, vokal berformant, jeda, dan desis tak bersuara.
import numpy as np, sys
from scipy.signal import lfilter
sr = int(sys.argv[1]); out = sys.argv[2]; dur = 7.0
rng = np.random.default_rng(7)
t = np.arange(int(sr * dur)) / sr
f0 = 118 + 14 * np.sin(2 * np.pi * 0.7 * t) + 6 * np.sin(2 * np.pi * 2.3 * t)
phase = np.cumsum(f0 / sr)
# sumber glotis: gelombang gigi gergaji yang dihaluskan (kaya harmonik)
src = np.zeros_like(t)
idx = np.where(np.diff(np.floor(phase)) > 0)[0]
src[idx] = 1.0
src = lfilter([1], [1, -0.97], src)           # kemiringan spektral
def res(x, f, bw):
    r = np.exp(-np.pi * bw / sr); th = 2 * np.pi * f / sr
    return lfilter([1 - r], [1, -2 * r * np.cos(th), r * r], x)
vow = [(700, 1100, 2500), (400, 1900, 2600), (300, 800, 2300), (550, 1500, 2500)]
y = np.zeros_like(t)
seglen = int(0.55 * sr)
for i in range(int(dur / 0.55) + 1):
    a, b = i * seglen, min((i + 1) * seglen, len(t))
    if a >= len(t): break
    f1, f2, f3 = vow[i % 4]
    s = src[a:b]
    v = res(res(res(s, f1, 90), f2, 110), f3, 170)
    env = np.ones(b - a)
    k = int(0.04 * sr); env[:k] = np.linspace(0, 1, k); env[-k:] = np.linspace(1, 0, k)
    y[a:b] = v * env
y /= np.max(np.abs(y)); y *= 0.35
# desis tak bersuara dan jeda
for st in (1.2, 3.1, 5.0):
    a = int(st * sr); b = a + int(0.18 * sr)
    n = rng.standard_normal(b - a); n = lfilter([1, -1], [1], n) * 0.04
    y[a:b] = n * np.hanning(b - a)
y[int(2.0 * sr):int(2.3 * sr)] = 0
y += 0.002 * rng.standard_normal(len(y))
y.astype(np.float32).tofile(out)
