// Tes host: jalankan mesin C++ pada file float32 mentah.
// pemakaian: test_engine in.f32 out.f32 sr block f0 formant inton tune delay_ms [rel_semi]
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "../native/src/engine.hpp"
int main(int argc, char** argv) {
  if (argc < 10) { fprintf(stderr, "argumen kurang\n"); return 2; }
  FILE* fi = fopen(argv[1], "rb"); if (!fi) return 3;
  std::vector<float> in; float buf[4096]; size_t r;
  while ((r = fread(buf, 4, 4096, fi)) > 0) in.insert(in.end(), buf, buf + r);
  fclose(fi);
  int sr = atoi(argv[3]), blk = atoi(argv[4]);
  mlv::Params p; p.f0 = atof(argv[5]); p.formant = atof(argv[6]); p.inton = atof(argv[7]); p.tune = atof(argv[8]);
  double delay = atof(argv[9]);
  if (argc > 10) { p.rel = true; p.relSemi = atof(argv[10]); }
  mlv::VoiceEngine e(sr);
  e.setParams(p); e.setActive(true); e.setDelayMs(delay);
  std::vector<float> out(in.size());
  for (size_t i = 0; i < in.size(); i += blk) {
    int n = (int)std::min<size_t>(blk, in.size() - i);
    e.process(in.data() + i, out.data() + i, n);
  }
  FILE* fo = fopen(argv[2], "wb"); fwrite(out.data(), 4, out.size(), fo); fclose(fo);
  fprintf(stderr, "heal=%d underrun=%d speakerF0=%.1f\n", e.stat().heal, e.stat().underrun, e.speakerF0());
  return 0;
}
