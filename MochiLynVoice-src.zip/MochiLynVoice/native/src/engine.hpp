// Mesin voice changer MochiLyn (cowok -> cewek). Port C++ dari voice-processor.js milik Sambung.
// Cara kerja: pelacak nada NSDF -> pitch mark -> sintesis PSOLA (jarak grain = nada, resample grain = formant).
// Bagian tak bersuara dilewatkan lewat grain identitas. Tanpa alokasi memori di jalur audio setelah konstruktor.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_SQRT1_2
#define M_SQRT1_2 0.70710678118654752440
#endif

namespace mlv {

constexpr int HOP = 128;
constexpr int RING = 1 << 15, RM = RING - 1;
constexpr int FRING = 512, FM = FRING - 1;
constexpr int MRING = 4096, MM = MRING - 1;
constexpr double V_ENTER = 0.45, V_STAY = 0.25, V_SURE = 0.5;
constexpr int V_HANG = 10;

inline double clampd(double v, double a, double b) { return v < a ? a : (v > b ? b : v); }
inline double jround(double x) { return std::floor(x + 0.5); }   // Math.round ala JavaScript

struct Params {
  double f0 = 225, formant = 1.17, inton = 1, tune = 0;
  bool rel = false;        // true: nada target = rata-rata nada pembicara + relSemi semitone
  double relSemi = 0;
};

struct Stat { double f0in = 0, f0out = 0; int voiced = 0, underrun = 0, heal = 0; };

class VoiceEngine {
 public:
  explicit VoiceEngine(int sampleRate)
      : sr_(sampleRate),
        xr(RING), xl(RING), xd(RING), ob(RING),
        fTag(FRING, -1), fV(FRING, 0), fT(FRING, 0), fRun(FRING, 0),
        mPos(MRING, 0), mPer(MRING, 0), mRun(MRING, 0), ref(2048, 0) {
    const double sr = sr_;
    D = std::max(1, (int)jround(sr / 8000));
    srd = sr / D;
    tauMin = std::max(4, (int)std::floor(srd / 500));
    tauMax = (int)std::ceil(srd / 70) + 2;
    W = 192;
    seg.assign(W + tauMax + 4, 0.f);
    nsdf.assign(tauMax + 4, 0.f);
    Tmax = sr / 70;
    Lq = (int)jround(0.045 * sr);
    HW = (int)std::ceil(Tmax) + 4;
    dc = (int)jround(W * D / 2.0 + 0.004 * sr);
    Hu = (int)jround(0.004 * sr);
    LqMin = dc + HW + 64;
    {
      const double wh = 2 * M_PI * 80 / sr, ch = std::cos(wh), ah = std::sin(wh) / (2 * M_SQRT1_2), a0h = 1 + ah;
      hb0 = ((1 + ch) / 2) / a0h; hb1 = -(1 + ch) / a0h; hb2 = hb0;
      ha1 = (-2 * ch) / a0h; ha2 = (1 - ah) / a0h;
    }
    {
      const double w0 = 2 * M_PI * 1000 / sr, cs = std::cos(w0), al = std::sin(w0) / (2 * M_SQRT1_2), a0 = 1 + al;
      lb0 = ((1 - cs) / 2) / a0; lb1 = (1 - cs) / a0; lb2 = lb0;
      la1 = (-2 * cs) / a0; la2 = (1 - al) / a0;
    }
    lnT = std::log(sr / 120);
    mu = std::log(125.0);
  }

  int sampleRate() const { return sr_; }
  int latencySamples() const { return Lq; }
  const Stat& stat() const { return stat_; }
  double speakerF0() const { return std::exp(mu); }

  // ---- pengaturan (panggil dari thread yang sama dengan process) ----
  void setParams(const Params& p) {
    P.f0 = clampd(p.f0, 100, 600);
    P.formant = clampd(p.formant, 0.85, 1.6);
    P.inton = clampd(p.inton, 0, 2);
    P.tune = clampd(p.tune, -15, 15);
    P.rel = p.rel;
    P.relSemi = clampd(p.relSemi, -24, 24);
  }
  void setActive(bool a) { mixTarget = a ? 1 : 0; }
  void setAutoHeal(bool a) { autoHeal = a; }
  void refresh() { if (!idle) hardReset(); }
  bool isIdle() const { return idle; }
  void setDelayMs(double ms) {
    const int L = std::max(LqMin, (int)jround(clampd(ms, 0, 500) / 1000 * sr_));
    if (L != Lq) { Lq = L; if (!idle) reset(); }
  }

  // ---------------------------------------------------------------- utama
  // inp boleh nullptr (dianggap hening). N <= 8192 per panggilan.
  void process(const float* inp, float* out, int N) {
    const int64_t n0 = n;
    const bool active = mixTarget > 0 || mix > 0;
    if (active && idle) wake();

    int pos = 0;
    while (pos < N) {
      const int take = std::min(N - pos, HOP - (int)(n & (HOP - 1)));
      for (int i = 0; i < take; i++) push(inp ? (double)inp[pos + i] : 0.0);
      pos += take;
      if ((n & (HOP - 1)) == 0 && !idle) analyze();
    }

    if (!idle) {
      const int64_t nEnd = n;
      const double lag = (double)((nEnd - Lq) - (int64_t)ts);
      if (!(lag == lag) || (autoHeal && (lag > 0.15 * sr_ || lag < -4.0 * HW))) { stat_.heal++; hardReset(); }
      synth((double)(nEnd - Lq + HW));
    }

    const int64_t e0 = n0 - Lq;
    double sOO = 0, sRR = 0, sOR = 0;
    for (int i = 0; i < N; i++) {
      double dry = inp ? (double)inp[i] : 0.0;
      if (!std::isfinite(dry)) dry = 0; else if (dry > 8) dry = 8; else if (dry < -8) dry = -8;
      double y = dry;
      if (!idle) {
        const int j = (int)((e0 + i) & RM);
        const double wet = (e0 + i) >= 0 ? (double)ob[j] : 0.0;
        ob[j] = 0.f;
        if (mix < mixTarget) mix = std::min((double)mixTarget, mix + mixStep());
        else if (mix > mixTarget) mix = std::max((double)mixTarget, mix - mixStep());
        y = dry + (wet - dry) * mix;
        if (!(y == y) || y > 1e4 || y < -1e4) { y = 0; reset(); }
        const double ay = y < 0 ? -y : y;
        if (ay > 0.8) y = (y < 0 ? -1 : 1) * (0.8 + 0.2 * std::tanh((ay - 0.8) / 0.2));
        if (muteN > 0) { muteN--; y = 0; }
        const double rw = (e0 + i) >= 0 ? (double)xr[j] : 0.0;
        sOO += y * y; sRR += rw * rw; sOR += y * rw;
      }
      out[i] = (float)y;
    }
    if (!idle) {
      emitted = e0 + N;
      if (mix == 0 && mixTarget == 0) idle = true;
      else watch(sOO, sRR, sOR, N);
    }
  }

 private:
  double mixStep() const { return 1.0 / (0.03 * sr_); }

  void watch(double sOO, double sRR, double sOR, int N) {
    if (!autoHeal || mixTarget < 1 || mix < 0.99) { leakN = 0; deadN = 0; return; }
    const double rIn = std::sqrt(sRR / N), rOut = std::sqrt(sOO / N);
    if (rIn < 0.01) { if (leakN > 0) leakN--; if (deadN > 0) deadN--; return; }
    const double rho = sOR / std::sqrt(sOO * sRR + 1e-12);
    const bool shifted = stat_.f0in > 0 && std::fabs(std::log(stat_.f0out / stat_.f0in)) > 0.15;
    if (rho > 0.92 && lastClarity >= 0.75 && shifted) leakN++; else leakN = std::max(0, leakN - 2);
    if (rOut < 0.05 * rIn) deadN++; else deadN = std::max(0, deadN - 2);
    if (leakN > 60 || deadN > 80) { stat_.heal++; hardReset(); }
  }

  void hardReset() {
    hx1 = hx2 = hy1 = hy2 = lx1 = lx2 = ly1 = ly2 = 0;
    std::fill(fTag.begin(), fTag.end(), -1);
    std::fill(fV.begin(), fV.end(), 0);
    if (!std::isfinite(mu)) { mu = std::log(125.0); muN = 0; }
    lnT = std::log(sr_ / 120.0); accD = 0; cntD = 0;
    leakN = 0; deadN = 0;
    muteN = (int)jround(0.05 * sr_);
    wake();
  }

  void wake() {
    idle = false;
    std::fill(ob.begin(), ob.end(), 0.f);
    ts = (double)(n - Lq);
    emitted = n - Lq;
    trk.active = false;
    vs = false; vc = 0; uc = 0; Tprev = 0; hn = 0;
    kLast = n / HOP - 1;
    mptr = mcount;
  }

  void reset() {
    std::fill(ob.begin(), ob.end(), 0.f);
    ts = (double)(n - Lq); emitted = n - Lq;
    trk.active = false; vs = false; vc = 0; uc = 0; Tprev = 0; hn = 0;
    hx1 = hx2 = hy1 = hy2 = lx1 = lx2 = ly1 = ly2 = 0;
  }

  void push(double x) {
    if (!std::isfinite(x)) x = 0;      // NaN/Inf -> hening (tambahan dari versi JS)
    else if (x > 8) x = 8; else if (x < -8) x = -8;
    const int i = (int)(n & RM);
    xr[i] = (float)x;
    const double h = hb0 * x + hb1 * hx1 + hb2 * hx2 - ha1 * hy1 - ha2 * hy2;
    hx2 = hx1; hx1 = x; hy2 = hy1; hy1 = h;
    const double y = lb0 * h + lb1 * lx1 + lb2 * lx2 - la1 * ly1 - la2 * ly2;
    lx2 = lx1; lx1 = h; ly2 = ly1; ly1 = y;
    xl[i] = (float)y;
    accD += y;
    if (++cntD == D) { xd[(int)(nd & RM)] = (float)(accD / D); nd++; accD = 0; cntD = 0; }
    n++;
  }

  // ---------------------------------------------------------------- analisis nada
  struct Cand { double tau, v; };

  void analyze() {
    const int64_t k = n / HOP;
    const int need = W + tauMax;
    bool haveCand = false; Cand cand{0, 0};
    double rmsB = 0;
    if (nd >= need + 4) {
      const int64_t st = nd - need;
      for (int i = 0; i < need; i++) seg[i] = xd[(int)((st + i) & RM)];
      double eB = 0;
      for (int j = 0; j < W; j++) { const double v = seg[tauMax + j]; eB += v * v; }
      rmsB = std::sqrt(eB / W);
      double eA = 0;
      { const int b = tauMax - tauMin; for (int j = 0; j < W; j++) { const double v = seg[b + j]; eA += v * v; } }
      for (int tau = tauMin; tau <= tauMax; tau++) {
        const int b = tauMax - tau;
        if (tau > tauMin) { const double a = seg[b], r = seg[b + W]; eA += a * a - r * r; }
        double dot = 0;
        for (int j = 0; j < W; j++) dot += (double)seg[b + j] * (double)seg[tauMax + j];
        nsdf[tau] = (float)(2 * dot / (eA + eB + 1e-12));
      }
      if (rmsB > 0.0007) haveCand = pickPeak(cand);
    }

    const double thr = vs ? V_STAY : V_ENTER;
    bool ok = haveCand && cand.v >= thr;
    if (ok && vs && Tprev > 0) {
      const double dj = std::fabs(std::log(cand.tau * D / Tprev));
      if ((cand.v < V_SURE && dj > 0.15) || (cand.v < 0.8 && dj > 0.35)) ok = false;
    }
    lastClarity = haveCand ? cand.v : 0;
    if (ok) { vc++; uc = 0; } else { uc++; vc = 0; }
    bool entering = false;
    if (!vs && vc >= 2) { vs = true; entering = true; run++; }
    else if (vs && uc >= V_HANG) { vs = false; Tprev = 0; }

    if (ok) {
      const double lt = std::log(cand.tau * D);
      if (entering) { hist[0] = hist[1] = hist[2] = lt; lnT = lt; }
      else { hist[0] = hist[1]; hist[1] = hist[2]; hist[2] = lt; }
      const double a = hist[0], b = hist[1], c = hist[2];
      const double med = std::max(std::min(a, b), std::min(std::max(a, b), c));
      lnT += (entering ? 1 : 0.4) * (med - lnT);
      lnT = clampd(lnT, std::log(sr_ / 500.0), std::log(Tmax));
      Tprev = std::exp(lnT);
      if (vs && cand.v >= 0.6) {
        const double lf = std::log((double)sr_) - lnT;
        if (std::fabs(lf - mu) < 0.6) {
          muN++;
          mu += (lf - mu) / std::min(4 + muN, 3000);
        }
      }
    }

    const double T = Tprev ? Tprev : std::exp(lnT);
    const int slot = (int)(k & FM);
    fTag[slot] = (int32_t)k; fV[slot] = vs ? 1 : 0; fT[slot] = (float)T; fRun[slot] = run;
    kLast = k;
    stat_.voiced = vs ? 1 : 0;
    if (vs) { stat_.f0in = sr_ / T; stat_.f0out = stat_.f0in * ratio(T); }

    track((double)(n - dc), T, vs, entering);
  }

  bool pickPeak(Cand& out) {
    float keysT[32], keysV[32];
    int nk = 0, tau = tauMin;
    while (tau < tauMax && nsdf[tau] > 0) tau++;
    while (tau < tauMax && nk < 32) {
      while (tau < tauMax && nsdf[tau] <= 0) tau++;
      int pk = -1; double pv = -1;
      while (tau < tauMax && nsdf[tau] > 0) { if (nsdf[tau] > pv) { pv = nsdf[tau]; pk = tau; } tau++; }
      if (pk > tauMin && pk < tauMax - 1) {
        const double a = nsdf[pk - 1], b = nsdf[pk], c = nsdf[pk + 1];
        const double den = a - 2 * b + c;
        const double off = den < -1e-9 ? 0.5 * (a - c) / den : 0;
        keysT[nk] = (float)(pk + clampd(off, -1, 1));
        keysV[nk] = (float)(b - 0.25 * (a - c) * off);
        nk++;
      }
    }
    if (!nk) return false;
    double vmax = 0;
    for (int i = 0; i < nk; i++) if (keysV[i] > vmax) vmax = keysV[i];
    if (vs && Tprev > 0) {
      int li = -1; double lv = -1;
      for (int i = 0; i < nk; i++) {
        if (std::fabs(std::log(keysT[i] * D / Tprev)) < 0.12 && keysV[i] > lv) { lv = keysV[i]; li = i; }
      }
      if (li >= 0 && lv >= 0.7 * vmax) { out = {keysT[li], lv}; return true; }
    }
    const double lim = 0.72 * vmax;
    int bi = -1; double bd = 1e9;
    for (int i = 0; i < nk; i++) {
      if (keysV[i] < lim) continue;
      if (vs && Tprev > 0) {
        const double d = std::fabs(std::log(keysT[i] * D / Tprev));
        if (d < bd) { bd = d; bi = i; }
      } else { bi = i; break; }
    }
    if (bi < 0) return false;
    out = {keysT[bi], keysV[bi]};
    return true;
  }

  // ---------------------------------------------------------------- pitch mark
  void track(double c, double T, bool voiced, bool entering) {
    if (!voiced) { trk.active = false; return; }
    if (entering || !trk.active) {
      const int64_t a = (int64_t)std::floor(c - T), b = (int64_t)std::floor(c);
      if (a <= n - RING + 64) return;
      double mx = -1e9, mn = 1e9; int64_t imx = a, imn = a;
      for (int64_t q = a; q <= b; q++) {
        const double v = xl[(int)(q & RM)];
        if (v > mx) { mx = v; imx = q; }
        if (v < mn) { mn = v; imn = q; }
      }
      trk.pol = mx >= -mn ? 1 : -1;
      trk.last = (double)(trk.pol > 0 ? imx : imn);
      trk.active = true;
      pushMark(trk.last, T);
    }
    int guard = 0;
    while (guard++ < 8) {
      const double pred = trk.last + T;
      if (pred > c + HOP) break;
      const double q = findNext(trk.last, T, pred, trk.pol);
      if (q < 0) break;
      trk.last = q;
      pushMark(q, T);
    }
  }

  void pushMark(double pos, double T) {
    const int i = (int)(mcount & MM);
    mPos[i] = pos; mPer[i] = (float)T; mRun[i] = run;
    mcount++;
  }

  double findNext(double lastD, double T, double pred, int pol) {
    const int64_t last = (int64_t)lastD;   // posisi selalu bulat
    const int h = (int)clampd(std::floor(0.3 * T), 8, 1000);
    const int range = std::max(4, (int)std::floor(0.25 * T));
    const int64_t pr = (int64_t)jround(pred);
    const int64_t lo = pr - range, hi = pr + range;
    if (hi + h + 2 >= n || last - h - 2 <= n - RING + 64) return -1;
    double er = 0;
    for (int j = -h; j <= h; j++) { const double v = xl[(int)((last + j) & RM)]; ref[j + h] = (float)v; er += v * v; }
    if (er < 1e-12) return (double)pr;
    auto score = [&](int64_t q) {
      double dot = 0, ec = 0;
      for (int j = -h; j <= h; j++) { const double v = xl[(int)((q + j) & RM)]; dot += (double)ref[j + h] * v; ec += v * v; }
      const double d = (double)(q - pr) / range;
      return dot / std::sqrt(er * ec + 1e-12) - 0.15 * d * d;
    };
    double best = -9; int64_t bq = pr;
    for (int64_t q = lo; q <= hi; q += 2) { const double s = score(q); if (s > best) { best = s; bq = q; } }
    for (int64_t q = bq - 1; q <= bq + 1; q += 2) { if (q < lo || q > hi) continue; const double s = score(q); if (s > best) { best = s; bq = q; } }
    const int sn = std::max(2, (int)jround(0.12 * T));
    int64_t pk = bq; double pv = pol * (double)xl[(int)(bq & RM)];
    for (int64_t q = bq - sn; q <= bq + sn; q++) { const double v = pol * (double)xl[(int)(q & RM)]; if (v > pv) { pv = v; pk = q; } }
    if ((double)pk <= (double)last + 0.5 * T) pk = (int64_t)jround((double)last + T);
    return (double)pk;
  }

  // ---------------------------------------------------------------- sintesis
  double ratio(double T) const {
    const double F0 = sr_ / T;
    double target;
    if (P.rel) target = std::exp(mu) * std::pow(2.0, (P.relSemi + P.tune) / 12);
    else target = P.f0 * std::pow(2.0, P.tune / 12);
    const double lo = clampd(std::log(target) + P.inton * (std::log(F0) - mu), std::log(60.0), std::log(1000.0));
    return clampd(std::exp(lo) / F0, 0.45, 6);
  }

  int64_t nearestMark(double tsv, int runv, double T) {
    if (mcount == 0) return -1;
    const int64_t lowest = std::max<int64_t>(0, mcount - MRING + 4);
    int64_t i = std::min(std::max(mptr, lowest), mcount - 1);
    while (i + 1 < mcount && std::fabs(mPos[(int)((i + 1) & MM)] - tsv) <= std::fabs(mPos[(int)(i & MM)] - tsv)) i++;
    while (i - 1 >= lowest && std::fabs(mPos[(int)((i - 1) & MM)] - tsv) < std::fabs(mPos[(int)(i & MM)] - tsv)) i--;
    mptr = i;
    if (mRun[(int)(i & MM)] != runv) return -1;
    if (std::fabs(mPos[(int)(i & MM)] - tsv) > 0.8 * T) return -1;
    return i;
  }

  void synth(double tsLimit) {
    int guard = 0;
    while (ts < tsLimit && guard++ < 200) {
      const double tsv = ts;
      const int64_t kf = (int64_t)std::floor((tsv + dc) / HOP);
      bool voiced = false; double T = 0; int runv = -1;
      if (kf <= kLast && kf > kLast - FRING + 8 && fTag[(int)(kf & FM)] == (int32_t)kf) {
        voiced = fV[(int)(kf & FM)] == 1; T = fT[(int)(kf & FM)]; runv = fRun[(int)(kf & FM)];
      } else if (tsv + dc > (double)n) {
        stat_.underrun++;
      }
      if (voiced) {
        const int64_t mi = nearestMark(tsv, runv, T);
        if (mi >= 0) {
          const double m = mPos[(int)(mi & MM)];
          const double Tm = mPer[(int)(mi & MM)];
          const double f = P.formant, p = ratio(T);
          const int Hin = (int)jround(std::min(Tm, T * 1.25));
          const int Hout = std::min(HW, std::max(8, (int)jround(Hin / f)));
          if (m + Hin + 4 < (double)n && m - Hin - 4 > (double)(n - RING + 64)) {
            grain(tsv, m, Hout, f, 1.15 * std::sqrt(f / p));
            ts = tsv + T / p;
            continue;
          }
        }
      }
      if (voiced) {
        const double f = P.formant, p = ratio(T);
        const int Hin = (int)jround(std::min(T, (double)HW));
        const int Hout = std::min(HW, std::max(8, (int)jround(Hin / f)));
        const double c = jround(tsv);
        if (c + Hin + 4 < (double)n && c - Hin - 4 > (double)(n - RING + 64)) {
          grain(tsv, c, Hout, f, 1.15 * std::sqrt(f / p));
          ts = tsv + T / p;
          continue;
        }
      }
      const int H = voiced ? std::min(HW, std::max(16, (int)jround(T))) : Hu;
      grain(tsv, tsv, H, 1, 1);
      ts = tsv + H;
    }
  }

  void grain(double tsv, double src, int H, double f, double gain) {
    const int64_t ti = (int64_t)std::floor(tsv);
    const double fr = tsv - (double)ti;
    const double pi = M_PI / (H + 1);
    const int64_t lowIdx = n - RING + 8;
    const int64_t first = std::max<int64_t>(-H, emitted - ti);
    for (int64_t k = first; k <= H; k++) {
      const double w = 0.5 + 0.5 * std::cos(pi * (double)k);
      const double r = src + ((double)k - fr) * f;
      const int64_t i0 = (int64_t)std::floor(r);
      if (i0 + 2 >= n || i0 - 1 < lowIdx) continue;
      const double u = r - (double)i0;
      const double a = xr[(int)((i0 - 1) & RM)], b = xr[(int)(i0 & RM)], c = xr[(int)((i0 + 1) & RM)], d = xr[(int)((i0 + 2) & RM)];
      const double s = b + 0.5 * u * (c - a + u * (2 * a - 5 * b + 4 * c - d + u * (3 * (b - c) + d - a)));
      const int oi = (int)((ti + k) & RM);
      ob[oi] = (float)((double)ob[oi] + gain * w * s);
    }
  }

  // ---- keadaan ----
  int sr_;
  int D = 1, tauMin = 4, tauMax = 0, W = 192, Lq = 0, HW = 0, dc = 0, Hu = 0, LqMin = 0;
  double srd = 0, Tmax = 0;
  std::vector<float> seg, nsdf, xr, xl, xd, ob;
  int64_t n = 0, nd = 0;
  double accD = 0; int cntD = 0;
  double hb0 = 0, hb1 = 0, hb2 = 0, ha1 = 0, ha2 = 0, lb0 = 0, lb1 = 0, lb2 = 0, la1 = 0, la2 = 0;
  double hx1 = 0, hx2 = 0, hy1 = 0, hy2 = 0, lx1 = 0, lx2 = 0, ly1 = 0, ly2 = 0;
  std::vector<int32_t> fTag; std::vector<uint8_t> fV; std::vector<float> fT; std::vector<int32_t> fRun;
  int64_t kLast = -1;
  bool vs = false; int vc = 0, uc = 0;
  double lnT = 0, Tprev = 0, hist[3] = {0, 0, 0}; int hn = 0;
  double mu = 0; int muN = 0;
  int run = 0;
  double lastClarity = 0;
  std::vector<double> mPos; std::vector<float> mPer; std::vector<int32_t> mRun;
  int64_t mcount = 0, mptr = 0;
  struct Trk { bool active = false; double last = 0; int pol = 1; } trk;
  std::vector<float> ref;
  double ts = 0; int64_t emitted = 0;
  double mix = 0; int mixTarget = 0;
  bool idle = true;
  Params P;
  Stat stat_;
  int muteN = 0;
  bool autoHeal = true;
  int leakN = 0, deadN = 0;
};

}  // namespace mlv
