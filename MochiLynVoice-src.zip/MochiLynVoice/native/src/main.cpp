// MochiLyn Voice - modul Zygisk (author: MochiLyn)
//
// Alur kerja:
//  - Di tiap app yang baru dibuka, modul bertanya ke proses "companion" (root) apakah app itu ada di daftar
//    /data/adb/mochilyn_voice/apps.txt. Kalau tidak, modul langsung melepas diri dari app itu (tanpa jejak).
//  - Kalau ya, modul mengganti fungsi baca mikrofon Java (android.media.AudioRecord.native_read_*): data asli dibaca dulu
//    oleh sistem, lalu diubah oleh mesin suara (engine.hpp), baru diserahkan ke app.
//  - Pengaturan (preset, nada, delay) dibaca companion dari /data/adb/mochilyn_voice/config.txt dan dikirim
//    ke app tiap ~1 detik, jadi ganti preset berlaku tanpa restart app.
//  - Aman-gagal: kalau ada yang salah (companion mati, hook tidak ketemu, mesin error), suara asli dilewatkan apa adanya.
#include <android/log.h>
#include <jni.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "engine.hpp"
#include "zygisk.hpp"

#define TAG "MochiLynVoice"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

#ifndef MLV_DIR
#define MLV_DIR "/data/adb/mochilyn_voice"
#endif
static const char* kDir = MLV_DIR;
static const uint32_t kMagic = 0x4D4C5631;   // "MLV1"

// ---------------------------------------------------------------------------------------------- protokol
struct Msg {
  uint32_t magic;
  uint8_t enabled;   // app ini boleh dihook (hanya relevan untuk balasan pertama)
  uint8_t active;    // preset mengubah suara (false = Normal/mati)
  uint8_t rel;       // true: nada = rata-rata pembicara + relSemi
  uint8_t autoheal;
  float f0, formant, inton, tune, relSemi, delay;
  uint32_t refreshN;
};

static bool readn(int fd, void* buf, size_t n) {
  char* p = (char*)buf;
  while (n) { ssize_t r = read(fd, p, n); if (r < 0 && errno == EINTR) continue; if (r <= 0) return false; p += r; n -= (size_t)r; }
  return true;
}
static bool writen(int fd, const void* buf, size_t n) {
  const char* p = (const char*)buf;
  while (n) { ssize_t r = write(fd, p, n); if (r < 0 && errno == EINTR) continue; if (r <= 0) return false; p += r; n -= (size_t)r; }
  return true;
}

// ---------------------------------------------------------------------------------------------- sisi companion (root)
struct Preset { const char* key; bool active, rel; float f0, formant, inton, relSemi; };
static const Preset kPresets[] = {
    {"plus11", true, true, 205, 1.18f, 1.1f, 11},   // Cewe natural, +11 semitone dari nada asli pembicara
    {"natural", true, false, 205, 1.18f, 1.1f, 0},  // sama dengan preset "Cewek natural" di Sambung
    {"teen", true, false, 225, 1.17f, 1.0f, 0},
    {"onee", true, false, 190, 1.12f, 0.9f, 0},
    {"anime", true, false, 250, 1.22f, 1.2f, 0},
    {"normal", false, false, 205, 1.18f, 1.1f, 0},
};

static std::string trim(std::string s) {
  size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
  return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

static Msg loadConfig() {
  Msg m;
  memset(&m, 0, sizeof m);
  m.magic = kMagic;
  std::string preset = "plus11";
  int enabled = 1, autoheal = 1;
  float tune = 0, delay = 45;
  uint32_t refreshN = 0;
  if (FILE* f = fopen((std::string(kDir) + "/config.txt").c_str(), "r")) {
    char line[256];
    while (fgets(line, sizeof line, f)) {
      std::string s = trim(line);
      if (s.empty() || s[0] == '#') continue;
      size_t eq = s.find('=');
      if (eq == std::string::npos) continue;
      std::string k = trim(s.substr(0, eq)), v = trim(s.substr(eq + 1));
      if (k == "preset") preset = v;
      else if (k == "enabled") enabled = atoi(v.c_str());
      else if (k == "autoheal") autoheal = atoi(v.c_str());
      else if (k == "tune") tune = (float)atof(v.c_str());
      else if (k == "delay") delay = (float)atof(v.c_str());
      else if (k == "refresh") refreshN = (uint32_t)strtoul(v.c_str(), nullptr, 10);
    }
    fclose(f);
  }
  const Preset* p = &kPresets[0];
  for (const Preset& q : kPresets) if (preset == q.key) { p = &q; break; }
  m.active = (enabled && p->active) ? 1 : 0;
  m.rel = p->rel; m.autoheal = autoheal ? 1 : 0;
  m.f0 = p->f0; m.formant = p->formant; m.inton = p->inton; m.relSemi = p->relSemi;
  m.tune = tune; m.delay = delay; m.refreshN = refreshN;
  return m;
}

static bool appAllowed(const std::string& proc, int uid) {
  if (uid < 10000) return false;                // jangan sentuh proses sistem
  FILE* f = fopen((std::string(kDir) + "/apps.txt").c_str(), "r");
  if (!f) return false;
  bool ok = false;
  char line[256];
  while (!ok && fgets(line, sizeof line, f)) {
    std::string s = trim(line);
    if (s.empty() || s[0] == '#') continue;
    if (s == "*") ok = true;
    else if (proc == s || (proc.size() > s.size() && proc.compare(0, s.size(), s) == 0 && proc[s.size()] == ':')) ok = true;  // com.app atau com.app:proses
  }
  fclose(f);
  return ok;
}

static bool readString(int fd, std::string& out) {
  uint32_t len = 0;
  if (!readn(fd, &len, 4) || len > 512) return false;
  out.assign(len, '\0');
  return len == 0 || readn(fd, &out[0], len);
}

static void companionHandler(int fd) {
  std::string proc;
  int32_t uid = 0;
  if (!readString(fd, proc) || !readn(fd, &uid, 4)) { close(fd); return; }
  Msg m = loadConfig();
  m.enabled = (appAllowed(proc, uid) && access(kDir, F_OK) == 0) ? 1 : 0;
  if (!writen(fd, &m, sizeof m)) { close(fd); return; }
  if (!m.enabled) { close(fd); return; }
  for (;;) {
    char cmd;
    if (!readn(fd, &cmd, 1)) break;
    if (cmd == 'C') {
      Msg c = loadConfig();
      c.enabled = 1;
      if (!writen(fd, &c, sizeof c)) break;
    } else if (cmd == 'H') {   // app melapor: hook mikrofon berhasil dipakai
      std::string info;
      if (!readString(fd, info)) break;
      mkdir((std::string(kDir) + "/status").c_str(), 0755);
      std::string name = proc;
      for (char& ch : name) if (ch == ':' || ch == '/') ch = '_';
      if (FILE* f = fopen((std::string(kDir) + "/status/" + name + ".txt").c_str(), "w")) {
        fprintf(f, "%s\nwaktu_unix=%ld\n", info.c_str(), (long)time(nullptr));
        fclose(f);
      }
    } else break;
  }
  close(fd);
}

// ---------------------------------------------------------------------------------------------- sisi app
static std::mutex g_mu;
static Msg g_msg;                       // konfigurasi terbaru (dilindungi g_mu)
static std::atomic<int> g_hit{0};       // 1 = ada laporan "hook berhasil" yang belum dikirim
static std::string g_hitInfo;           // dilindungi g_mu
static std::string g_proc;
static int g_fd = -1;

static jclass g_clsSys = nullptr;
static jmethodID g_mHash = nullptr, g_mSr = nullptr, g_mCh = nullptr, g_mFmt = nullptr;

static jint (*o_byte)(JNIEnv*, jobject, jbyteArray, jint, jint, jboolean) = nullptr;
static jint (*o_short)(JNIEnv*, jobject, jshortArray, jint, jint, jboolean) = nullptr;
static jint (*o_float)(JNIEnv*, jobject, jfloatArray, jint, jint, jboolean) = nullptr;
static jint (*o_direct)(JNIEnv*, jobject, jobject, jint, jboolean) = nullptr;

struct Slot {
  int key = 0, sr = 0, ch = 0, fmt = 0;
  std::unique_ptr<mlv::VoiceEngine> eng;
  uint64_t used = 0;
  uint32_t refreshSeen = 0;
  bool reported = false;
};
static Slot g_slots[4];
static uint64_t g_tick = 0;

static int qint(JNIEnv* env, jobject o, jmethodID m) {
  int v = env->CallIntMethod(o, m);
  if (env->ExceptionCheck()) { env->ExceptionClear(); return -1; }
  return v;
}

// Ambil/siapkan mesin untuk satu objek AudioRecord. Dipanggil dengan g_mu terkunci.
static Slot* slotFor(JNIEnv* env, jobject thiz) {
  int key = env->CallStaticIntMethod(g_clsSys, g_mHash, thiz);
  if (env->ExceptionCheck()) { env->ExceptionClear(); return nullptr; }
  Slot* s = nullptr;
  for (Slot& x : g_slots) if (x.eng && x.key == key) { s = &x; break; }
  if (!s) {
    Slot* old = &g_slots[0];
    for (Slot& x : g_slots) { if (!x.eng) { old = &x; break; } if (x.used < old->used) old = &x; }
    s = old;
    s->eng.reset();
    s->key = key; s->sr = qint(env, thiz, g_mSr); s->ch = qint(env, thiz, g_mCh); s->fmt = qint(env, thiz, g_mFmt);
    s->reported = false;
    if (s->sr < 8000 || s->sr > 96000 || s->ch < 1 || s->ch > 2 || (s->fmt != 2 && s->fmt != 4)) { s->sr = 0; return nullptr; }  // hanya PCM16 / float
    s->eng.reset(new mlv::VoiceEngine(s->sr));
    s->refreshSeen = g_msg.refreshN;
  }
  s->used = ++g_tick;
  return s->sr ? s : nullptr;
}

static void applyConfig(Slot* s) {
  mlv::Params p;
  p.f0 = g_msg.f0; p.formant = g_msg.formant; p.inton = g_msg.inton; p.tune = g_msg.tune;
  p.rel = g_msg.rel != 0; p.relSemi = g_msg.relSemi;
  s->eng->setParams(p);
  s->eng->setActive(g_msg.active != 0);
  s->eng->setAutoHeal(g_msg.autoheal != 0);
  s->eng->setDelayMs(g_msg.delay);
  if (g_msg.refreshN != s->refreshSeen) { s->refreshSeen = g_msg.refreshN; s->eng->refresh(); }
}

// frames: jumlah frame (tiap frame = ch sampel). Format PCM16 atau float, interleaved.
template <typename T> static void processBuffer(Slot* s, T* data, int frames);
template <> void processBuffer<int16_t>(Slot* s, int16_t* d, int frames) {
  float in[2048], out[2048];
  const int ch = s->ch;
  for (int off = 0; off < frames; off += 2048) {
    const int n = std::min(2048, frames - off);
    for (int i = 0; i < n; i++) {
      int sum = 0;
      for (int c = 0; c < ch; c++) sum += d[(size_t)(off + i) * ch + c];
      in[i] = (float)sum / (float)ch / 32768.f;
    }
    s->eng->process(in, out, n);
    for (int i = 0; i < n; i++) {
      float v = out[i] * 32768.f;
      v = v > 32767.f ? 32767.f : (v < -32768.f ? -32768.f : v);
      const int16_t q = (int16_t)(v >= 0 ? v + 0.5f : v - 0.5f);
      for (int c = 0; c < ch; c++) d[(size_t)(off + i) * ch + c] = q;
    }
  }
}
template <> void processBuffer<float>(Slot* s, float* d, int frames) {
  float in[2048], out[2048];
  const int ch = s->ch;
  for (int off = 0; off < frames; off += 2048) {
    const int n = std::min(2048, frames - off);
    for (int i = 0; i < n; i++) {
      float sum = 0;
      for (int c = 0; c < ch; c++) sum += d[(size_t)(off + i) * ch + c];
      in[i] = sum / (float)ch;
    }
    s->eng->process(in, out, n);
    for (int i = 0; i < n; i++) for (int c = 0; c < ch; c++) d[(size_t)(off + i) * ch + c] = out[i];
  }
}

// Titik masuk bersama. Mengembalikan true kalau data diubah. fmtWanted: 2 = PCM16, 4 = float.
template <typename T>
static bool transformAudio(JNIEnv* env, jobject thiz, T* data, int count, int fmtWanted) {
  std::lock_guard<std::mutex> lk(g_mu);
  Slot* s = slotFor(env, thiz);
  if (!s || s->fmt != fmtWanted) return false;
  if (!g_msg.active && s->eng->isIdle()) return false;     // Normal/mati: jangan sentuh data sama sekali
  applyConfig(s);
  const int frames = count / s->ch;
  if (frames <= 0) return false;
  processBuffer<T>(s, data, frames);
  if (!s->reported) {
    s->reported = true;
    char b[200];
    snprintf(b, sizeof b, "Java AudioRecord terhubung: proses=%s sr=%d ch=%d format=%s", g_proc.c_str(), s->sr, s->ch, s->fmt == 2 ? "PCM16" : "float");
    LOGI("%s", b);
    g_hitInfo = b;
    g_hit.store(1);
  }
  return true;
}

static thread_local std::vector<int16_t> t_s16;
static thread_local std::vector<float> t_f32;

static jint h_byte(JNIEnv* env, jobject thiz, jbyteArray arr, jint off, jint size, jboolean blocking) {
  if (!o_byte) return -3;
  jint r = o_byte(env, thiz, arr, off, size, blocking);
  if (r <= 1 || env->ExceptionCheck() || !arr) return r;
  try {
    const int samples = r / 2;
    if (t_s16.size() < (size_t)samples) t_s16.resize((size_t)samples);
    env->GetByteArrayRegion(arr, off, samples * 2, reinterpret_cast<jbyte*>(t_s16.data()));
    if (env->ExceptionCheck()) { env->ExceptionClear(); return r; }
    if (transformAudio<int16_t>(env, thiz, t_s16.data(), samples, 2)) env->SetByteArrayRegion(arr, off, samples * 2, reinterpret_cast<const jbyte*>(t_s16.data()));
  } catch (...) {}
  return r;
}

static jint h_short(JNIEnv* env, jobject thiz, jshortArray arr, jint off, jint size, jboolean blocking) {
  if (!o_short) return -3;
  jint r = o_short(env, thiz, arr, off, size, blocking);
  if (r <= 0 || env->ExceptionCheck() || !arr) return r;
  try {
    if (t_s16.size() < (size_t)r) t_s16.resize((size_t)r);
    env->GetShortArrayRegion(arr, off, r, reinterpret_cast<jshort*>(t_s16.data()));
    if (env->ExceptionCheck()) { env->ExceptionClear(); return r; }
    if (transformAudio<int16_t>(env, thiz, t_s16.data(), r, 2)) env->SetShortArrayRegion(arr, off, r, reinterpret_cast<const jshort*>(t_s16.data()));
  } catch (...) {}
  return r;
}

static jint h_float(JNIEnv* env, jobject thiz, jfloatArray arr, jint off, jint size, jboolean blocking) {
  if (!o_float) return -3;
  jint r = o_float(env, thiz, arr, off, size, blocking);
  if (r <= 0 || env->ExceptionCheck() || !arr) return r;
  try {
    if (t_f32.size() < (size_t)r) t_f32.resize((size_t)r);
    env->GetFloatArrayRegion(arr, off, r, t_f32.data());
    if (env->ExceptionCheck()) { env->ExceptionClear(); return r; }
    if (transformAudio<float>(env, thiz, t_f32.data(), r, 4)) env->SetFloatArrayRegion(arr, off, r, t_f32.data());
  } catch (...) {}
  return r;
}

static jint h_direct(JNIEnv* env, jobject thiz, jobject buf, jint size, jboolean blocking) {
  if (!o_direct) return -3;
  jint r = o_direct(env, thiz, buf, size, blocking);
  if (r <= 1 || env->ExceptionCheck() || !buf) return r;
  try {
    void* p = env->GetDirectBufferAddress(buf);
    if (!p || (reinterpret_cast<uintptr_t>(p) & 1)) return r;
    // format diketahui dari slot: coba PCM16 dulu, lalu float
    int key = env->CallStaticIntMethod(g_clsSys, g_mHash, thiz);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return r; }
    int fmt = 0;
    { std::lock_guard<std::mutex> lk(g_mu); for (Slot& x : g_slots) if (x.eng && x.key == key) fmt = x.fmt; }
    if (!fmt) fmt = qint(env, thiz, g_mFmt);
    if (fmt == 2) transformAudio<int16_t>(env, thiz, static_cast<int16_t*>(p), r / 2, 2);
    else if (fmt == 4 && (reinterpret_cast<uintptr_t>(p) & 3) == 0) transformAudio<float>(env, thiz, static_cast<float*>(p), r / 4, 4);
  } catch (...) {}
  return r;
}

static void* pollThread(void*) {
  for (;;) {
    struct timespec ts = {1, 0};
    nanosleep(&ts, nullptr);
    if (g_fd < 0) return nullptr;
    if (g_hit.exchange(0)) {
      std::string info;
      { std::lock_guard<std::mutex> lk(g_mu); info = g_hitInfo; }
      uint32_t len = (uint32_t)info.size();
      char cmd = 'H';
      if (!writen(g_fd, &cmd, 1) || !writen(g_fd, &len, 4) || !writen(g_fd, info.data(), len)) return nullptr;
    }
    char cmd = 'C';
    Msg m;
    if (!writen(g_fd, &cmd, 1) || !readn(g_fd, &m, sizeof m) || m.magic != kMagic) return nullptr;   // companion hilang: pakai konfigurasi terakhir
    std::lock_guard<std::mutex> lk(g_mu);
    g_msg = m;
  }
}

class MochiModule : public zygisk::ModuleBase {
 public:
  void onLoad(zygisk::Api* api, JNIEnv* env) override { api_ = api; env_ = env; }

  void preAppSpecialize(zygisk::AppSpecializeArgs* args) override {
    enabled_ = false;
    std::string proc;
    if (args->nice_name) {
      const char* n = env_->GetStringUTFChars(args->nice_name, nullptr);
      if (n) { proc = n; env_->ReleaseStringUTFChars(args->nice_name, n); }
    }
    if (!proc.empty()) {
      int fd = api_->connectCompanion();
      if (fd >= 0) {
        uint32_t len = (uint32_t)proc.size();
        int32_t uid = (int32_t)args->uid;
        Msg m;
        struct timeval tv = {3, 0};
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
        if (writen(fd, &len, 4) && writen(fd, proc.data(), len) && writen(fd, &uid, 4) && readn(fd, &m, sizeof m) &&
            m.magic == kMagic && m.enabled) {
          g_msg = m; g_proc = proc; g_fd = fd; enabled_ = true;
        } else {
          close(fd);
        }
      }
    }
    if (!enabled_) api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);   // app lain: lepas modul sepenuhnya
  }

  void postAppSpecialize(const zygisk::AppSpecializeArgs*) override {
    if (!enabled_) return;
    if (!installHooks()) {
      LOGW("hook AudioRecord gagal dipasang di %s, suara asli dibiarkan", g_proc.c_str());
      close(g_fd); g_fd = -1;
      return;
    }
    pthread_t th;
    if (pthread_create(&th, nullptr, pollThread, nullptr) == 0) pthread_detach(th);
    LOGI("aktif di %s", g_proc.c_str());
  }

  void preServerSpecialize(zygisk::ServerSpecializeArgs*) override {
    api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);   // jangan masuk ke system_server
  }

 private:
  bool installHooks() {
    jclass ar = env_->FindClass("android/media/AudioRecord");
    jclass sys = env_->FindClass("java/lang/System");
    if (!ar || !sys) { env_->ExceptionClear(); return false; }
    g_mSr = env_->GetMethodID(ar, "getSampleRate", "()I");
    g_mCh = env_->GetMethodID(ar, "getChannelCount", "()I");
    g_mFmt = env_->GetMethodID(ar, "getAudioFormat", "()I");
    g_mHash = env_->GetStaticMethodID(sys, "identityHashCode", "(Ljava/lang/Object;)I");
    if (env_->ExceptionCheck()) env_->ExceptionClear();
    if (!g_mSr || !g_mCh || !g_mFmt || !g_mHash) return false;
    g_clsSys = (jclass)env_->NewGlobalRef(sys);
    if (!g_clsSys) return false;

    JNINativeMethod ms[4] = {
        {const_cast<char*>("native_read_in_byte_array"), const_cast<char*>("([BIIZ)I"), (void*)h_byte},
        {const_cast<char*>("native_read_in_short_array"), const_cast<char*>("([SIIZ)I"), (void*)h_short},
        {const_cast<char*>("native_read_in_float_array"), const_cast<char*>("([FIIZ)I"), (void*)h_float},
        {const_cast<char*>("native_read_in_direct_buffer"), const_cast<char*>("(Ljava/lang/Object;IZ)I"), (void*)h_direct},
    };
    api_->hookJniNativeMethods(env_, "android/media/AudioRecord", ms, 4);
    // setelah pemanggilan, fnPtr berisi fungsi ASLI (nullptr kalau metode tidak ketemu = tidak dihook)
    o_byte = reinterpret_cast<decltype(o_byte)>(ms[0].fnPtr);
    o_short = reinterpret_cast<decltype(o_short)>(ms[1].fnPtr);
    o_float = reinterpret_cast<decltype(o_float)>(ms[2].fnPtr);
    o_direct = reinterpret_cast<decltype(o_direct)>(ms[3].fnPtr);
    LOGI("hook: byte=%d short=%d float=%d direct=%d", o_byte != nullptr, o_short != nullptr, o_float != nullptr, o_direct != nullptr);
    return o_byte || o_short || o_float || o_direct;
  }

  zygisk::Api* api_ = nullptr;
  JNIEnv* env_ = nullptr;
  bool enabled_ = false;
};

REGISTER_ZYGISK_MODULE(MochiModule)
REGISTER_ZYGISK_COMPANION(companionHandler)
