# MochiLyn Voice Changer (Magisk / Zygisk) v0.1.0 - by MochiLyn

Mengubah suara mic cowok jadi cewek natural (+11 semitone) di app pilihan, misalnya WhatsApp dan Roblox.
Mesin suaranya port C++ dari voice changer Sambung (hasilnya identik dengan versi web, sudah diuji).

## Status jujur
- Mesin suara: diuji di PC (identik dengan versi JS, tahan banting lewat fuzz ASan/UBSan).
- Logika modul (companion, config, preset, pencocokan app, jalur PCM16): diuji di PC.
- BELUM dikompilasi untuk ARM dan BELUM diuji di HP. Pemasangan hook ke AudioRecord memakai header Zygisk resmi
  yang diunduh saat build; cocok tidaknya dengan Magisk-mu baru terlihat saat dicoba.
- Hanya menangkap app yang membaca mic lewat Java `AudioRecord`. App yang memakai jalur native (OpenSL ES / AAudio / Oboe)
  tidak tersentuh. Perintah `su -c mlv status` menunjukkan app mana yang benar-benar terhubung.
- Tidak ada EQ per preset (di Sambung ada). Hanya mesin nada dan formant.

## Cara kerja
1. Saat sebuah app dibuka, modul bertanya ke proses companion (root) apakah app itu ada di `apps.txt`. Kalau tidak, modul melepas diri dari app itu.
2. Kalau ya, modul mengganti fungsi baca mic (`AudioRecord.native_read_*`): sistem membaca suara asli, mesin mengubahnya, app menerima hasilnya.
3. Preset/nada/delay dibaca dari `/data/adb/mochilyn_voice/config.txt` dan dikirim ke app tiap ~1 detik (tanpa restart app).
4. Aman-gagal: kalau hook tidak ketemu atau companion mati, suara asli lewat apa adanya. Modul tidak menyentuh system_server dan tidak mengganti file sistem,
   jadi risiko bootloop kecil. Kalau ada masalah: matikan modul di Magisk, atau dari recovery hapus folder `/data/adb/modules/mochilyn_voice`.

## Build (pilih satu)
### A. GitHub Actions (cukup dari HP)
1. Buat repo GitHub baru. Unggah file zip sumber ini (satu file) lewat Add file > Upload files.
2. Add file > Create new file, ketik nama `.github/workflows/build.yml`, tempel isi file itu dari zip ini, simpan.
3. Tab Actions > build-magisk-module > Run workflow. Selesai, unduh artifact `MochiLynVoice-magisk` (berisi zip modul).
### B. PC dengan NDK
`export ANDROID_NDK_HOME=/path/ndk && ./build.sh` menghasilkan `MochiLynVoice-v0.1.0.zip`.
Kalau unduhan `zygisk.hpp` gagal, salin header resmi dari repo Magisk ke `native/src/zygisk.hpp` lalu ulangi.

## Pasang
1. Magisk > Pengaturan > nyalakan **Zygisk**. Pastikan WhatsApp/Roblox tidak ada di DenyList.
2. Magisk > Modul > Pasang dari penyimpanan > pilih zip hasil build > reboot.
3. Buka app, lakukan panggilan atau rekam pesan suara. Cek: `su -c mlv status` (Termux).

## Ganti preset (menu)
- Tombol **Action** modul di aplikasi Magisk (Magisk 27+) = preset berikutnya.
- Atau Termux: `su -c mlv next`, `mlv set natural`, `mlv list`, `mlv tune 1.5`, `mlv delay 60`, `mlv refresh`, `mlv on|off`, `mlv add com.paket.app`.
- Preset: plus11 (Cewe natural +11, bawaan), natural, teen, onee, anime, normal.

## Kalau tidak berubah suaranya
- `su -c mlv status` kosong di bagian "Hook aktif": app memakai jalur audio native atau tidak ada di `apps.txt`. Kirim hasil `logcat -s MochiLynVoice` untuk dilanjutkan ke hook native.
- Modul tidak termuat sama sekali: versi API Zygisk di header mungkin lebih baru dari Magisk-mu. Pakai header versi lebih lama.

## Uji di PC
`bash test/run_tests.sh` (butuh g++, node, python3 + numpy/scipy).
