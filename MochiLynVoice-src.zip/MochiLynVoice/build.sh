#!/usr/bin/env bash
# Build modul Magisk -> MochiLynVoice-<versi>.zip
# Butuh: Android NDK (env ANDROID_NDK_HOME atau ANDROID_NDK_LATEST_HOME), cmake, zip, curl.
# Di GitHub Actions (ubuntu-latest) semuanya sudah tersedia.
set -euo pipefail
cd "$(dirname "$0")"

NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
[ -n "$NDK" ] && [ -f "$NDK/build/cmake/android.toolchain.cmake" ] || { echo "NDK tidak ketemu. Set ANDROID_NDK_HOME."; exit 1; }

# --- header Zygisk resmi (ABI harus persis sama dengan Magisk, jadi tidak ditulis ulang manual) ---
HDR=native/src/zygisk.hpp
if [ ! -f "$HDR" ]; then
  URLS="${ZYGISK_HPP_URL:-} \
https://raw.githubusercontent.com/topjohnwu/zygisk-module-sample/master/module/jni/zygisk.hpp \
https://raw.githubusercontent.com/topjohnwu/zygisk-module-sample/main/module/jni/zygisk.hpp \
https://raw.githubusercontent.com/topjohnwu/Magisk/master/native/src/core/zygisk/api.hpp"
  for u in $URLS; do
    [ -n "$u" ] || continue
    echo "mencoba $u"
    if curl -fsSL "$u" -o "$HDR.tmp" && grep -q "REGISTER_ZYGISK_MODULE" "$HDR.tmp"; then mv "$HDR.tmp" "$HDR"; break; fi
    rm -f "$HDR.tmp"
  done
fi
[ -f "$HDR" ] || { echo "Gagal mengunduh zygisk.hpp. Salin file resminya ke $HDR lalu jalankan ulang."; exit 1; }
grep -m1 -n "ZYGISK_API_VERSION" "$HDR" || true

VER=$(sed -n 's/^version=//p' module/module.prop)
rm -rf build module/zygisk && mkdir -p module/zygisk
for ABI in arm64-v8a armeabi-v7a; do
  cmake -S native -B "build/$ABI" -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
        -DANDROID_ABI="$ABI" -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
  cmake --build "build/$ABI" -j"$(nproc)"
  cp "build/$ABI/libmochilyn_voice.so" "module/zygisk/$ABI.so"
  "$NDK"/toolchains/llvm/prebuilt/*/bin/llvm-strip --strip-unneeded "module/zygisk/$ABI.so" || true
done

OUT="MochiLynVoice-$VER.zip"
rm -f "$OUT"
(cd module && zip -r9 -X "../$OUT" . -x '*.DS_Store')
echo "SELESAI: $OUT"
unzip -l "$OUT"
