#!/system/bin/sh
rm -rf /data/adb/mochilyn_voice
