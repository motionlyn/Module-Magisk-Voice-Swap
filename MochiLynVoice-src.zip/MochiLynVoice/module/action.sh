#!/system/bin/sh
# Tombol "Action" di aplikasi Magisk (Magisk 27+): ganti ke preset berikutnya.
MODDIR=${0%/*}
sh "$MODDIR/system/bin/mlv" next
sh "$MODDIR/system/bin/mlv" status
