#!/system/bin/sh
# Installer MochiLyn Voice Changer (dijalankan oleh Magisk saat modul dipasang)
DATA=/data/adb/mochilyn_voice

ui_print "- MochiLyn Voice Changer v0.1.0 (by MochiLyn)"

# --- cek syarat; semua cek di sini hanya membatalkan pemasangan, tidak mengubah sistem ---
[ "$MAGISK_VER_CODE" -ge 24000 ] 2>/dev/null || abort "! Butuh Magisk 24 atau lebih baru (ada Zygisk)."
[ "$API" -ge 26 ] 2>/dev/null || abort "! Butuh Android 8.0 ke atas."
case "$ARCH" in
  arm64) ABI=arm64-v8a ;;
  arm)   ABI=armeabi-v7a ;;
  *)     abort "! Arsitektur $ARCH belum didukung." ;;
esac
[ -f "$MODPATH/zygisk/$ABI.so" ] || abort "! File zygisk/$ABI.so tidak ada. Zip ini belum dibuild: ambil zip hasil build (lihat README)."

ZY=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk'" 2>/dev/null)
case "$ZY" in
  *value=1*) ui_print "- Zygisk: aktif" ;;
  *) ui_print "! Zygisk belum aktif. Magisk > Pengaturan > Zygisk (nyalakan), lalu reboot." ;;
esac

# --- folder data + berkas pengaturan (tidak menimpa punyamu kalau sudah ada) ---
mkdir -p "$DATA/status"
[ -f "$DATA/config.txt" ] || cp "$MODPATH/defaults/config.txt" "$DATA/config.txt"
[ -f "$DATA/apps.txt" ]   || cp "$MODPATH/defaults/apps.txt" "$DATA/apps.txt"
chmod 755 "$DATA" "$DATA/status"; chmod 644 "$DATA/config.txt" "$DATA/apps.txt"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/system/bin/mlv" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755

ui_print "- Selesai. Preset bawaan: Cewe natural +11."
ui_print "- App aktif: lihat $DATA/apps.txt (bawaan: WhatsApp, WA Business, Roblox)."
ui_print "- Ganti preset: tombol Action modul ini di Magisk, atau 'su -c mlv next'."
ui_print "- Pastikan app tsb TIDAK ada di DenyList Magisk. Reboot dulu."
